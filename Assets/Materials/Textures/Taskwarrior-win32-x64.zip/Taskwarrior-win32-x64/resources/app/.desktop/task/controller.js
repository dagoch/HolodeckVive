'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.TaskController=undefined;var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _provider=require('./provider');
var _format=require('./format');
var _events=require('../tool/events');
var _style=require('../styles/style');
var _main=require('../styles/main');function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}var
StreamEater=function(){function StreamEater(){_classCallCheck(this,StreamEater);}_createClass(StreamEater,[{key:'eat',value:function eat(
line){

}},{key:'end',value:function end()

{
}}]);return StreamEater;}();


var specialReports=[
"burndown.daily",
"burndown.monthly",
"burndown.weekly",
"calendar",
"colors",
"export",
"ghistory.annual",
"ghistory.monthly",
"history.annual",
"history.monthly",
"information",
"summary",
"timesheet",
"projects",
"tags"];


var dayNames=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];var

ToArrayEater=function(_StreamEater){_inherits(ToArrayEater,_StreamEater);

function ToArrayEater(){_classCallCheck(this,ToArrayEater);var _this=_possibleConstructorReturn(this,(ToArrayEater.__proto__||Object.getPrototypeOf(ToArrayEater)).call(this));

_this.data=[];return _this;
}_createClass(ToArrayEater,[{key:'eat',value:function eat(

line){
this.data.push(line);
}}]);return ToArrayEater;}(StreamEater);var


ToStringEater=function(_ToArrayEater){_inherits(ToStringEater,_ToArrayEater);function ToStringEater(){_classCallCheck(this,ToStringEater);return _possibleConstructorReturn(this,(ToStringEater.__proto__||Object.getPrototypeOf(ToStringEater)).apply(this,arguments));}_createClass(ToStringEater,[{key:'str',value:function str()
{
return this.data.join('\n').trim();
}}]);return ToStringEater;}(ToArrayEater);var


TaskController=function(){

function TaskController(){_classCallCheck(this,TaskController);
this.fixParams=['rc.confirmation=off','rc.color=off','rc.verbose=nothing'];
this.events=new _events.EventEmitter();
this.timers={};
}_createClass(TaskController,[{key:'call',value:function call(

args,out,err,options){var result;return regeneratorRuntime.async(function call$(_context){while(1){switch(_context.prev=_context.next){case 0:_context.prev=0;_context.next=3;return regeneratorRuntime.awrap(

this.provider.call(this.fixParams.concat(args),out,err,options));case 3:result=_context.sent;
if(out&&out.end)out.end(result);
if(err&&err.end)err.end(result);return _context.abrupt('return',
result);case 9:_context.prev=9;_context.t0=_context['catch'](0);

console.log('Error calling task:',_context.t0);return _context.abrupt('return',
-1);case 13:
;case 14:case'end':return _context.stop();}}},null,this,[[0,9]]);}},{key:'err',value:function err(


message){
this.events.emit('notify:error',message);
}},{key:'info',value:function info(

message){
this.events.emit('notify:info',message);
}},{key:'streamNotify',value:function streamNotify()

{var _this3=this;var evt=arguments.length>0&&arguments[0]!==undefined?arguments[0]:'notify:error';
var stream=new ToStringEater();
stream.end=function(){
var message=stream.str();
if(message){
_this3.events.emit(evt,message);
};
};
return stream;
}},{key:'notifyChange',value:function notifyChange()

{
this.events.emit('change');
}},{key:'callStr',value:function callStr(

args){var out,code;return regeneratorRuntime.async(function callStr$(_context2){while(1){switch(_context2.prev=_context2.next){case 0:
out=new ToStringEater();_context2.next=3;return regeneratorRuntime.awrap(
this.call(args,out,this.streamNotify()));case 3:code=_context2.sent;if(!(
code!=0)){_context2.next=6;break;}return _context2.abrupt('return',
undefined);case 6:
;return _context2.abrupt('return',
out.str());case 8:case'end':return _context2.stop();}}},null,this);}},{key:'init',value:function init(){var _this4=this;var


config=arguments.length>0&&arguments[0]!==undefined?arguments[0]:{};var provider,css,reportsConf;return regeneratorRuntime.async(function init$(_context5){while(1){switch(_context5.prev=_context5.next){case 0:
delete this.provider;
config.onQuestion=function(text,choices){
return new Promise(function(resp,rej){
_this4.events.emit('question',text,choices,resp,rej);
});
};
config.onTimer=function _callee(type){var success;return regeneratorRuntime.async(function _callee$(_context3){while(1){switch(_context3.prev=_context3.next){case 0:if(!(
type=='sync')){_context3.next=6;break;}_context3.next=3;return regeneratorRuntime.awrap(
_this4.sync());case 3:success=_context3.sent;
if(success){
_this4.info('Automatically synchronized');
};case 6:
;case 7:case'end':return _context3.stop();}}},null,_this4);};

this.foreground=true;
config.onState=function _callee2(state,mode){var auto,success;return regeneratorRuntime.async(function _callee2$(_context4){while(1){switch(_context4.prev=_context4.next){case 0:

if(state=='active'){
_this4.foreground=true;
_this4.notifyChange();
};
if(state=='background'){
_this4.foreground=false;
};
if(state=='sync'&&mode){
_this4.notifyChange();
};if(!(
state=='online')){_context4.next=15;break;}
auto=_this4.timers.extra.auto;if(!

auto){_context4.next=14;break;}_context4.next=11;return regeneratorRuntime.awrap(

_this4.sync());case 11:success=_context4.sent;
if(success){
_this4.info('Automatically synchronized');
};case 14:
;case 15:
;case 16:case'end':return _context4.stop();}}},null,_this4);};

provider=new _provider.TaskProvider(config);_context5.next=8;return regeneratorRuntime.awrap(
provider.init());case 8:if(_context5.sent){_context5.next=10;break;}return _context5.abrupt('return',
false);case 10:
;
this.provider=provider;_context5.next=14;return regeneratorRuntime.awrap(
this.setupSync());case 14:
this.scheduleSync();_context5.next=17;return regeneratorRuntime.awrap(
this.loadConfig());case 17:this.configCache=_context5.sent;
this.dueDays=parseInt(this.config('due'))||7;
this.defaultCmd=this.config('default.command')||'next';_context5.next=22;return regeneratorRuntime.awrap(
this.loadPanesConfig());case 22:this.panesConfig=_context5.sent;_context5.next=25;return regeneratorRuntime.awrap(
this.loadUDAs());case 25:
this.multiline={};
(this.config('ui.multiline')||'').split(',').map(function(item){return item.trim();}).forEach(function(item){
if(item)_this4.multiline[item]=true;
});
this.multilineSep=this.config('ui.multiline.separator')||'\\n';
this.reportExtra=this.config('ui.report.extra.',true);
css=this.config('ui.style.',true);
(0,_style.init)(css);
(0,_main.init)(css,this);
this.cssConfig=css;_context5.next=35;return regeneratorRuntime.awrap(
this.loadCalendar());case 35:this.calendarConfig=_context5.sent;
reportsConf=this.config('ui.reports');
if(reportsConf){
this.reportsSublist=reportsConf.split(',').map(function(x){return x.trim();});
};if(!
provider.start){_context5.next=42;break;}_context5.next=42;return regeneratorRuntime.awrap(provider.start(this));case 42:return _context5.abrupt('return',
true);case 43:case'end':return _context5.stop();}}},null,this);}},{key:'readLimit',value:function readLimit(


value){
if(value==='off'){
return-1;
};
if(value&&parseInt(value)>0)
return parseInt(value);
return 0;
}},{key:'providerInfo',value:function providerInfo()

{
return this.provider.info||{};
}},{key:'fromCalendar',value:function fromCalendar()

{
var dt=new Date();
dt.setDate(1);
return dt;
}},{key:'loadPanesConfig',value:function loadPanesConfig(){var config,conf,pageParser;return regeneratorRuntime.async(function loadPanesConfig$(_context6){while(1){switch(_context6.prev=_context6.next){case 0:


config=this.config('ui.pane.',true);
conf={
expanded:config['tasks.expanded']=='off'?false:true,
limit:this.readLimit(config['tasks.limit']),
left:config.left,
right:config.right,
pins:[],
pages:[],
tags:config.tags||'scroll',
projects:config.projects||'scroll',
reports:config.reports||'scroll',
contexts:config.contexts||'compact',
popup:{
enabled:config.popup=='on',
active:config['popup.active'],
x:config['popup.x'],
y:config['popup.y'],
width:config['popup.w'],
height:config['popup.h'],
corner:config['popup.corner'],
screen:config['popup.screen']},

uda:config.uda?config.uda==='none'?false:config.uda.split(','):true};

pageParser=function pageParser(item){
var report=item.trim();
var filter='';
var sp=report.indexOf(' ');
if(sp!=-1){
filter=report.substr(sp).trim();
report=report.substr(0,sp).trim();
};
return{report:report,filter:filter};
};
if(config.pin){
conf.pins=config.pin.split(',').map(pageParser);
};
conf.pages=(config['default']||this.defaultCmd).split(',').map(pageParser);return _context6.abrupt('return',
this.provider.configurePanes(conf));case 7:case'end':return _context6.stop();}}},null,this);}},{key:'loadCalendar',value:function loadCalendar(){var dayNo,conf,result;return regeneratorRuntime.async(function loadCalendar$(_context7){while(1){switch(_context7.prev=_context7.next){case 0:



dayNo=function dayNo(name){var def=arguments.length>1&&arguments[1]!==undefined?arguments[1]:-1;
var index=dayNames.indexOf(name);
if(index==-1)return def;
return index;
};
conf=this.config('ui.calendar.',true);
result={
start:dayNo(conf['weekstart'],0),
pane:conf['pane']||'right',
command:conf['cmd']||'due',
commandAlt:conf['cmd.alt']||'wait',
filter:conf['filter']||'due.after',
filterAlt:conf['filter.alt']||'due.before',
weekends:[0,6]};

if(conf['weekends']){
result.weekends=[];
conf['weekends'].split(',').forEach(function(item){
var num=dayNo(item.trim());
if(num!=-1)result.weekends.push(num);
});
}return _context7.abrupt('return',
result);case 5:case'end':return _context7.stop();}}},null,this);}},{key:'loadUDAs',value:function loadUDAs(){var conf,key,parts,obj;return regeneratorRuntime.async(function loadUDAs$(_context8){while(1){switch(_context8.prev=_context8.next){case 0:



conf=this.config('uda.',true);
this.udas={};_context8.t0=regeneratorRuntime.keys(
conf);case 3:if((_context8.t1=_context8.t0()).done){_context8.next=13;break;}key=_context8.t1.value;
parts=key.split('.');if(!(
parts.length!=2)){_context8.next=8;break;}return _context8.abrupt('continue',3);case 8:
obj=this.udas[parts[0]]||{};
obj[parts[1]]=conf[key];
this.udas[parts[0]]=obj;_context8.next=3;break;case 13:case'end':return _context8.stop();}}},null,this);}},{key:'udaPanels',value:function udaPanels()



{var
uda=this.panesConfig.uda;
if(uda===false){
return[];
};
var result=[];
for(var key in this.udas){
var value=this.udas[key];
if(value.type!=='string'){
continue;
};
if(uda===true||uda.includes(key)){
result.push({
id:key,
label:value.label,
values:value.values.split(',')});

};
};
if(uda===true){
result.sort(function(a,b){
return a.id>b.id?1:-1;
});
}else{
result.sort(function(a,b){
return uda.indexOf(a.id)-uda.indexOf(b.id);
});
};
return result;
}},{key:'specialList',value:function specialList(

type){var report;return regeneratorRuntime.async(function specialList$(_context9){while(1){switch(_context9.prev=_context9.next){case 0:
report=this.config('ui.report.'+type,true);
if(!report)report={};return _context9.abrupt('return',
report['']||this.defaultCmd);case 3:case'end':return _context9.stop();}}},null,this);}},{key:'setupSync',value:function setupSync(){var _this5=this;var timers;return regeneratorRuntime.async(function setupSync$(_context10){while(1){switch(_context10.prev=_context10.next){case 0:



timers=this.config('ui.sync.',true);
this.timers=this.provider.configureSync(timers);
['normal','error','commit'].forEach(function(field){
if(timers[field]!==undefined){
_this5.timers[field]=parseInt(timers[field],10);
};
});
this.timers.extra=this.config('ui.sync.extra.',true)||{};
console.log('setupSync:',this.timers);case 5:case'end':return _context10.stop();}}},null,this);}},{key:'confBool',value:function confBool(


value){
if(value===undefined||value===''){
return undefined;
};
if(['on','y','yes','true','t','1'].includes(value)){
return true;
};
return false;
}},{key:'scheduleSync',value:function scheduleSync()

{var type=arguments.length>0&&arguments[0]!==undefined?arguments[0]:'normal';
var timeout=this.timers[type]||this.timers.normal||0;
if(timeout>0&&this.provider){
this.provider.schedule(timeout*60,'sync',true,this.timers);
};
}},{key:'reportInfo',value:function reportInfo(

report){var result,desc,ruleConf,ctxConf,config,key,_iteratorNormalCompletion,_didIteratorError,_iteratorError,_iterator,_step,s,item,columnsStr,_iteratorNormalCompletion2,_didIteratorError2,_iteratorError2,_iterator2,_step2,_s,cm,labelsStr,i,_iteratorNormalCompletion3,_didIteratorError3,_iteratorError3,_iterator3,_step3;return regeneratorRuntime.async(function reportInfo$(_context11){while(1){switch(_context11.prev=_context11.next){case 0:
result={
sort:[],
cols:[],
report:report,
filter:'',
precedence:[]};

desc=[];
ruleConf=this.config('rule.precedence.color');
if(ruleConf){
result.precedence=ruleConf.split(',').reverse();
};
ctxConf=this.config('context',true);
if(ctxConf['']){
result.context=ctxConf['.'+ctxConf.context];
}
config=this.config('report.'+report+'.',true);_context11.t0=regeneratorRuntime.keys(
config);case 9:if((_context11.t1=_context11.t0()).done){_context11.next=60;break;}key=_context11.t1.value;if(!(
key=='sort')){_context11.next=32;break;}_iteratorNormalCompletion=true;_didIteratorError=false;_iteratorError=undefined;_context11.prev=15;
for(_iterator=config[key].split(',')[typeof Symbol==='function'?typeof Symbol==='function'?typeof Symbol==='function'?Symbol.iterator:'@@iterator':'@@iterator':'@@iterator']();!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=true){s=_step.value;
item={
field:s,
asc:true};

if(item.field[item.field.length-1]=='/'){

item.sep=true;
item.field=item.field.substr(0,item.field.length-1);
};
item.asc=item.field[item.field.length-1]=='+';
item.field=item.field.substr(0,item.field.length-1);
result.sort.push(item);
}_context11.next=23;break;case 19:_context11.prev=19;_context11.t2=_context11['catch'](15);_didIteratorError=true;_iteratorError=_context11.t2;case 23:_context11.prev=23;_context11.prev=24;if(!_iteratorNormalCompletion&&_iterator.return){_iterator.return();}case 26:_context11.prev=26;if(!_didIteratorError){_context11.next=29;break;}throw _iteratorError;case 29:return _context11.finish(26);case 30:return _context11.finish(23);case 31:;case 32:
;if(!(
key=='columns')){_context11.next=55;break;}
columnsStr=config[key];
if(this.reportExtra.columns)columnsStr+=','+this.reportExtra.columns;_iteratorNormalCompletion2=true;_didIteratorError2=false;_iteratorError2=undefined;_context11.prev=39;
for(_iterator2=columnsStr.split(',')[typeof Symbol==='function'?typeof Symbol==='function'?typeof Symbol==='function'?Symbol.iterator:'@@iterator':'@@iterator':'@@iterator']();!(_iteratorNormalCompletion2=(_step2=_iterator2.next()).done);_iteratorNormalCompletion2=true){_s=_step2.value;
cm=_s.indexOf('.');
if(cm==-1){
result.cols.push({
field:_s,
full:_s,
display:''});

}else{
result.cols.push({
field:_s.substr(0,cm),
display:_s.substr(cm+1),
full:_s});

}
}_context11.next=47;break;case 43:_context11.prev=43;_context11.t3=_context11['catch'](39);_didIteratorError2=true;_iteratorError2=_context11.t3;case 47:_context11.prev=47;_context11.prev=48;if(!_iteratorNormalCompletion2&&_iterator2.return){_iterator2.return();}case 50:_context11.prev=50;if(!_didIteratorError2){_context11.next=53;break;}throw _iteratorError2;case 53:return _context11.finish(50);case 54:return _context11.finish(47);case 55:

if(key=='labels'){
labelsStr=config[key];
if(this.reportExtra.labels)labelsStr+=','+this.reportExtra.labels;
desc=labelsStr.split(',');
}
if(key=='description'){
result.description=config[key];
}
if(key=='filter'){
result.filter=config[key];
}_context11.next=9;break;case 60:

if(!result.description)result.description=result.filter;
result.sort.push({
field:'id',
asc:true},
{
field:'description',
asc:true});if(!(

desc.length==result.cols.length)){_context11.next=66;break;}

for(i=0;i<desc.length;i++){
result.cols[i].label=desc[i];
}_context11.next=85;break;case 66:_iteratorNormalCompletion3=true;_didIteratorError3=false;_iteratorError3=undefined;_context11.prev=69;

for(_iterator3=result.cols[typeof Symbol==='function'?typeof Symbol==='function'?typeof Symbol==='function'?Symbol.iterator:'@@iterator':'@@iterator':'@@iterator']();!(_iteratorNormalCompletion3=(_step3=_iterator3.next()).done);_iteratorNormalCompletion3=true){col=_step3.value;
col.label=col.field;
}_context11.next=77;break;case 73:_context11.prev=73;_context11.t4=_context11['catch'](69);_didIteratorError3=true;_iteratorError3=_context11.t4;case 77:_context11.prev=77;_context11.prev=78;if(!_iteratorNormalCompletion3&&_iterator3.return){_iterator3.return();}case 80:_context11.prev=80;if(!_didIteratorError3){_context11.next=83;break;}throw _iteratorError3;case 83:return _context11.finish(80);case 84:return _context11.finish(77);case 85:return _context11.abrupt('return',

result);case 86:case'end':return _context11.stop();}}},null,this,[[15,19,23,31],[24,,26,30],[39,43,47,55],[48,,50,54],[69,73,77,85],[78,,80,84]]);}},{key:'exp',value:function exp(


cmds){var cmd,result,code;return regeneratorRuntime.async(function exp$(_context12){while(1){switch(_context12.prev=_context12.next){case 0:
cmd=['rc.json.array=off'].concat(cmds);
cmd.push('export');
result=[];_context12.next=5;return regeneratorRuntime.awrap(
this.call(cmd,{
eat:function eat(line){
if(!line){
return;
}

try{
var json=JSON.parse(line);
if(json.depends&&!Array.isArray(json.depends)){
json.depends=json.depends.split(',');
};
json.unique=json.id||json.uuid;
result.push(json);
}catch(e){
console.log('JSON error:',line);
}
}},
this.streamNotify()));case 5:code=_context12.sent;if(!(
code!=0)){_context12.next=9;break;}
console.log('Failure:',cmd,code);return _context12.abrupt('return',
undefined);case 9:return _context12.abrupt('return',

result);case 10:case'end':return _context12.stop();}}},null,this);}},{key:'filterSimple',value:function filterSimple(


report){var info,cmd,expResult;return regeneratorRuntime.async(function filterSimple$(_context13){while(1){switch(_context13.prev=_context13.next){case 0:_context13.next=2;return regeneratorRuntime.awrap(
this.reportInfo(report));case 2:info=_context13.sent;if(
info){_context13.next=6;break;}
this.err('Invalid input');return _context13.abrupt('return',
undefined);case 6:

cmd=[];
if(info.context){
cmd.push('('+info.context+')');
}
if(info.filter){
cmd.push('('+info.filter+')');
}_context13.next=11;return regeneratorRuntime.awrap(
this.exp(cmd));case 11:expResult=_context13.sent;if(
expResult){_context13.next=14;break;}return _context13.abrupt('return',
undefined);case 14:
;
info.tasks=expResult;return _context13.abrupt('return',
info.tasks);case 17:case'end':return _context13.stop();}}},null,this);}},{key:'filter',value:function filter(


report,_filter,info){var _this6=this;var sortMode=arguments.length>3&&arguments[3]!==undefined?arguments[3]:'list';var cmd,expResult,hasDepends,i;return regeneratorRuntime.async(function filter$(_context15){while(1){switch(_context15.prev=_context15.next){case 0:if(!(
!info||info.report!=report)){_context15.next=4;break;}_context15.next=3;return regeneratorRuntime.awrap(
this.reportInfo(report));case 3:info=_context15.sent;case 4:if(

info){_context15.next=7;break;}
this.err('Invalid input');return _context15.abrupt('return',
undefined);case 7:

info.tasks=[];
cmd=[];
if(info.context){
cmd.push('('+info.context+')');
}
if(info.filter){
cmd.push('('+info.filter+')');
}
if(_filter){
cmd.push(_filter);
}_context15.next=14;return regeneratorRuntime.awrap(
this.exp(cmd));case 14:expResult=_context15.sent;if(
expResult){_context15.next=17;break;}return _context15.abrupt('return',
undefined);case 17:
;
info.tasks=expResult;
hasDepends=false;
info.cols.forEach(function(item){
if(item.field=='depends'){
hasDepends=true;
};
});if(!
hasDepends){_context15.next=24;break;}_context15.next=24;return regeneratorRuntime.awrap(function _callee3(){var all_uuids,task,uuids,uuidsTasks,_task;return regeneratorRuntime.async(function _callee3$(_context14){while(1){switch(_context14.prev=_context14.next){case 0:
all_uuids={};
for(i=0;i<info.tasks.length;i++){
task=info.tasks[i];
if(task.depends){
task.depends.forEach(function(uuid){return all_uuids[uuid]=null;});
};
};
uuids=Object.keys(all_uuids).
map(function(uuid){return'uuid:'+uuid.substr(0,8);}).join(' or ');if(!
uuids){_context14.next=10;break;}_context14.next=7;return regeneratorRuntime.awrap(
_this6.exp([uuids]));case 7:uuidsTasks=_context14.sent;
if(uuidsTasks){
uuidsTasks.forEach(function(t){return all_uuids[t.uuid]=t;});
for(i=0;i<info.tasks.length;i++){
_task=info.tasks[i];
if(_task.depends&&_task.depends.length){
_task.dependsTasks=_task.depends.
map(function(uuid){return all_uuids[uuid];}).
filter(function(t){return t&&t.id>0;});
};
};
};case 10:
;case 11:case'end':return _context14.stop();}}},null,_this6);}());case 24:
;

info.cols.forEach(function(item){
item.visible=false;
item.multiline=false;
if('status'==item.field){
return;
}
if(_this6.multiline[item.field]){
item.multiline=true;
item.visible=true;
};
if(item.field=='depends'){
hasDepends=true;
};
var handler=_format.formatters[item.field];
if(!handler){
if(_this6.udas[item.field]){
handler=_format.formatters.uda;
}
};

var max=0;

info.tasks.forEach(function(task){
var val=handler?handler(task,item.display,item,_this6):task[item.field]||'';
task[item.full+'_']=val;
if(item.multiline){
var lines=[''];
if(val){
lines=val.split(_this6.multilineSep);
};
task[item.full+'_lines']=lines;
return;
};
if(val.length>max){
max=val.length;
};

});
if(max>0||['id','uuid','description'].indexOf(item.field)!=-1){
item.visible=true;
item.width=Math.max(max,item.label.length);

};
});
info.tasks=(0,_format.sortTasks)(info,sortMode);
if(this.panesConfig.limit>0){
info.tasks=info.tasks.slice(0,this.panesConfig.limit);
};

info.tasks.forEach(function(task){
task.styles=(0,_format.calcColorStyles)(task,info.precedence,_this6);
});return _context15.abrupt('return',

info);case 31:case'end':return _context15.stop();}}},null,this);}},{key:'undo',value:function undo(){var code;return regeneratorRuntime.async(function undo$(_context16){while(1){switch(_context16.prev=_context16.next){case 0:_context16.next=2;return regeneratorRuntime.awrap(



this.call(['undo'],null,this.streamNotify(),{
slow:true,
question:true}));case 2:code=_context16.sent;


if(code==0){
this.notifyChange();
this.scheduleSync('commit');
};return _context16.abrupt('return',
code);case 6:case'end':return _context16.stop();}}},null,this);}},{key:'cmd',value:function cmd(


_cmd,input){var tasks=arguments.length>2&&arguments[2]!==undefined?arguments[2]:[];var silent=arguments.length>3&&arguments[3]!==undefined?arguments[3]:false;var cmds,ids,code;return regeneratorRuntime.async(function cmd$(_context17){while(1){switch(_context17.prev=_context17.next){case 0:
cmds=[];
ids=tasks.map(function(task){
return task.id||task.uuid_||task.uuid;
});
if(ids.length){
cmds.push(ids.join(','));
};
cmds.push(_cmd);
cmds.push(input);_context17.next=8;return regeneratorRuntime.awrap(

this.call(cmds,this.streamNotify('notify:info'),this.streamNotify(),{
slow:true,
question:true}));case 8:code=_context17.sent;if(!(


code===0)){_context17.next=13;break;}
if(!silent){
this.notifyChange();
this.scheduleSync('commit');
};return _context17.abrupt('return',
true);case 13:
;return _context17.abrupt('return',
false);case 15:case'end':return _context17.stop();}}},null,this);}},{key:'cmdRaw',value:function cmdRaw(


cmd,handler){var out,err,stream2result,code,result;return regeneratorRuntime.async(function cmdRaw$(_context18){while(1){switch(_context18.prev=_context18.next){case 0:
out=new ToArrayEater();
err=new ToArrayEater();
stream2result=function stream2result(stream,type){
return stream.data.map(function(line){
return{
line:line,type:type};

});
};
code=void 0;_context18.prev=4;_context18.next=7;return regeneratorRuntime.awrap(

this.provider.call([cmd],out,err,{
slow:true,
question:true,
flush:function flush(){
handler&&handler({lines:stream2result(out,'out')});
}}));case 7:code=_context18.sent;_context18.next=14;break;case 10:_context18.prev=10;_context18.t0=_context18['catch'](4);


console.log('Error:',_context18.t0);
code=-1;case 14:
;
result=stream2result(out,'out').concat(stream2result(err,'error'));
result.push({
type:'info',
line:'Exit code: '+code});return _context18.abrupt('return',

{
lines:result});case 18:case'end':return _context18.stop();}}},null,this,[[4,10]]);}},{key:'sync',value:function sync(){var code;return regeneratorRuntime.async(function sync$(_context19){while(1){switch(_context19.prev=_context19.next){case 0:




this.events.emit('sync:start');_context19.next=3;return regeneratorRuntime.awrap(
this.call(['sync'],null,this.streamNotify(),{
slow:true,
question:true}));case 3:code=_context19.sent;

this.events.emit('sync:finish');
if(code==0){
this.notifyChange();
this.scheduleSync();
}else{
this.scheduleSync('error');
}return _context19.abrupt('return',
code==0);case 7:case'end':return _context19.stop();}}},null,this);}},{key:'loadConfig',value:function loadConfig(){var reg,result,args;return regeneratorRuntime.async(function loadConfig$(_context20){while(1){switch(_context20.prev=_context20.next){case 0:



reg=/^([a-z0-9_\.]+)=(.+)$/;
result={};
args=['_show'];_context20.next=5;return regeneratorRuntime.awrap(
this.call(args,{
eat:function eat(line){
if(line){

var m=line.match(reg);
if(m){
var key=m[1].trim();
result[key]=m[2].trim();
}
}
}},
this.streamNotify()));case 5:return _context20.abrupt('return',
result);case 6:case'end':return _context20.stop();}}},null,this);}},{key:'config',value:function config(


prefix,strip_prefix){
var result={};
if(!strip_prefix){
return this.configCache[prefix];
};
for(var key in this.configCache){
if(key.indexOf(prefix)==0){
result[key.substr(prefix.length)]=this.configCache[key];
};
}
return result;
}},{key:'tags',value:function tags(

expanded){var reg,result,added;return regeneratorRuntime.async(function tags$(_context21){while(1){switch(_context21.prev=_context21.next){case 0:
reg=/^(.+)\s(\d+)$/;
result=[];
added={};if(!
expanded){_context21.next=9;break;}_context21.next=6;return regeneratorRuntime.awrap(
this.call(['_unique','tag'],{
eat:function eat(line){
if(line){
var tag=line.split(',')[0];
if(added[tag])return;
added[tag]=true;
result.push({
name:tag});

}
}},
this.streamNotify()));case 6:return _context21.abrupt('return',
result);case 9:_context21.next=11;return regeneratorRuntime.awrap(

this.call(['tags'],{
eat:function eat(line){
var m=line.match(reg);
if(m){
result.push({
name:m[1].trim(),
count:parseInt(m[2],10)});

}
}},
this.streamNotify()));case 11:return _context21.abrupt('return',
result.sort(function(a,b){
return b.count-a.count;
}));case 12:case'end':return _context21.stop();}}},null,this);}},{key:'setContext',value:function setContext(



context){var code;return regeneratorRuntime.async(function setContext$(_context22){while(1){switch(_context22.prev=_context22.next){case 0:_context22.next=2;return regeneratorRuntime.awrap(
this.cmd('context',context));case 2:code=_context22.sent;if(!(
code==0)){_context22.next=6;break;}
this.notifyChange();return _context22.abrupt('return',
true);case 6:return _context22.abrupt('return',

false);case 7:case'end':return _context22.stop();}}},null,this);}},{key:'contexts',value:function contexts(){var conf,result,current,key;return regeneratorRuntime.async(function contexts$(_context23){while(1){switch(_context23.prev=_context23.next){case 0:



conf=this.config('context',true);
result=[];
current='none';
for(key in conf){
if(key==''){
current=conf.context;
}else{

result.push({
name:key.substr(1),
context:key.substr(1),
filter:conf[key]});

}
}if(
result.length){_context23.next=6;break;}return _context23.abrupt('return',
undefined);case 6:

result.splice(0,0,{
name:'(none)',
context:'none',
filter:'Context not set'});

result.forEach(function(item){
item.selected=current==item.context;
});return _context23.abrupt('return',
result);case 9:case'end':return _context23.stop();}}},null,this);}},{key:'reports',value:function reports(


expanded){var reg,result,map;return regeneratorRuntime.async(function reports$(_context24){while(1){switch(_context24.prev=_context24.next){case 0:
reg=/^(\S+)\s(.+)$/;
result=[];_context24.next=4;return regeneratorRuntime.awrap(
this.call(['reports'],{
eat:function eat(line){
var m=line.match(reg);
if(m){
var report=m[1].trim();
result.push({
name:report,
title:m[2].trim(),
special:specialReports.indexOf(report)!=-1});

}
}},
this.streamNotify()));case 4:if(!(
!expanded&&this.reportsSublist)){_context24.next=8;break;}
map={};
result.forEach(function(item){
map[item.name]=item;
});return _context24.abrupt('return',
this.reportsSublist.map(function(report){return map[report];}).filter(function(report){return report;}));case 8:
;return _context24.abrupt('return',
result.filter(function(item,idx){
return idx<result.length-1;
}));case 10:case'end':return _context24.stop();}}},null,this);}},{key:'projects',value:function projects(


expanded){var reg,result,added,processOne,roots;return regeneratorRuntime.async(function projects$(_context25){while(1){switch(_context25.prev=_context25.next){case 0:
reg=/^(\s*)(.+)\s(\d+)$/;
result=[];if(!
expanded){_context25.next=8;break;}
added={};_context25.next=6;return regeneratorRuntime.awrap(
this.call(['_unique','project'],{
eat:function eat(line){
var parts=line.split('.');
var full='';
parts.forEach(function(p,idx){
full+='.'+p;
if(added[full])return;
result.push({
name:p,
indent:idx*2,
children:[]});

added[full]=true;
});
}},
this.streamNotify()));case 6:_context25.next=10;break;case 8:_context25.next=10;return regeneratorRuntime.awrap(

this.call(['projects'],{
eat:function eat(line){
var m=line.match(reg);
if(m){
result.push({
name:m[2].trim(),
indent:m[1].length,
count:parseInt(m[3],10),
children:[]});

}
}},
this.streamNotify()));case 10:

processOne=function processOne(from,arr,indent,prefix){
for(var i=from;i<result.length;i++){
var item=result[i];
if(item.indent==indent){
item.project=prefix+item.name;
if(item.name=='(none)'){
item.project='';
}
arr.push(item);
}
if(item.indent>indent){

var p=arr[arr.length-1];
i=processOne(i,p.children,item.indent,p.project+'.');
continue;
}
if(item.indent<indent){

return i-1;
}
}
return result.length;
};
roots=[];
processOne(0,roots,0,'');return _context25.abrupt('return',
roots);case 14:case'end':return _context25.stop();}}},null,this);}},{key:'editConfig',value:function editConfig(){return regeneratorRuntime.async(function editConfig$(_context26){while(1){switch(_context26.prev=_context26.next){case 0:if(



this.provider.editConfig){_context26.next=3;break;}
this.err('Not available on this platform');return _context26.abrupt('return');case 3:

;_context26.prev=4;_context26.next=7;return regeneratorRuntime.awrap(

this.provider.editConfig());case 7:_context26.next=16;break;case 9:_context26.prev=9;_context26.t0=_context26['catch'](4);

console.log('Error:',_context26.t0);if(!(
_context26.t0.code=='no_editor')){_context26.next=14;break;}return _context26.abrupt('return',
this.err('No editor app associated with plain-text files. Install one'));case 14:
;
this.err('Edit error');case 16:case'end':return _context26.stop();}}},null,this,[[4,9]]);}},{key:'makeBackup',value:function makeBackup(){return regeneratorRuntime.async(function makeBackup$(_context27){while(1){switch(_context27.prev=_context27.next){case 0:_context27.prev=0;_context27.next=3;return regeneratorRuntime.awrap(





this.provider.backup());case 3:_context27.next=9;break;case 5:_context27.prev=5;_context27.t0=_context27['catch'](0);

console.log('Backup error:',_context27.t0);
this.err(_context27.t0.message);case 9:case'end':return _context27.stop();}}},null,this,[[0,5]]);}},{key:'calendar',value:function calendar(



from){
var dt=void 0;
if(!from){
dt=new Date();
}else{
dt=new Date(from.getTime());
}
dt.setDate(1);
var m=dt.getMonth();
var start=this.calendarConfig.start;
var weekends=this.calendarConfig.weekends;
if(dt.getDay()<start){
dt.setDate(1+start-dt.getDay()-7);
}else{
dt.setDate(1+start-dt.getDay());
}
var result=[];
do{
var week=[];
for(var i=0;i<7;i++){
week.push({
day:dt.getDate(),
date:(0,_format.isoDate)(dt),
active:dt.getMonth()===m,
weekend:weekends.includes(dt.getDay())});

dt.setDate(dt.getDate()+1);
};
result.push(week);
}while(dt.getMonth()==m);
return result;
}},{key:'popupEnabled',value:function popupEnabled()

{
return this.panesConfig.popup.enabled||false;
}},{key:'makePopupData',value:function makePopupData(){var active;return regeneratorRuntime.async(function makePopupData$(_context28){while(1){switch(_context28.prev=_context28.next){case 0:_context28.next=2;return regeneratorRuntime.awrap(


this.filterSimple(this.panesConfig.popup.active||'active'));case 2:active=_context28.sent;return _context28.abrupt('return',
{
active:active.length>0});case 4:case'end':return _context28.stop();}}},null,this);}}]);return TaskController;}();exports.TaskController=TaskController;