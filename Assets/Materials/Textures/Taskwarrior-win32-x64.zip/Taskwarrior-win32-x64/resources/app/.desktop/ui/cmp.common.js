'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.CalendarPane=exports.ContextsList=exports.ReportsList=exports.TagsNavigation=exports.UdaPane=exports.ProjectsNavigation=exports.CmdPageCmp=exports.TaskPageCmp=undefined;var _get=function get(object,property,receiver){if(object===null)object=Function.prototype;var desc=Object.getOwnPropertyDescriptor(object,property);if(desc===undefined){var parent=Object.getPrototypeOf(object);if(parent===null){return undefined;}else{return get(parent,property,receiver);}}else if("value"in desc){return desc.value;}else{var getter=desc.get;if(getter===undefined){return undefined;}return getter.call(receiver);}};var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _jsxFileName='C:\\Users\\Michael\\src\\task\\app\\ui\\cmp.common.js';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _react=require('react');var _react2=_interopRequireDefault(_react);
var _main=require('../styles/main');
var _widget=require('./widget');var widget=_interopRequireWildcard(_widget);function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}else{var newObj={};if(obj!=null){for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key))newObj[key]=obj[key];}}newObj.default=obj;return newObj;}}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var

Task=function(_widget$DnD){_inherits(Task,_widget$DnD);

function Task(props){_classCallCheck(this,Task);var _this=_possibleConstructorReturn(this,(Task.__proto__||Object.getPrototypeOf(Task)).call(this,
props));
_this.dropTypes.push('tw/tag','tw/project','tw/task','tw/date','tw/property');
_this.state={
dependsVisible:false,
collapsed:true};return _this;

}_createClass(Task,[{key:'onDropHandler',value:function onDropHandler(

type,data,e){
this.props.onDrop(type,data,e);
}},{key:'toggleDepends',value:function toggleDepends()

{
this.setState({
dependsVisible:!this.state.dependsVisible});

}},{key:'toggleExpand',value:function toggleExpand()

{
this.setState({
collapsed:!this.state.collapsed});

}},{key:'render',value:function render()

{var _this2=this;var _props=

















this.props,cols=_props.cols,task=_props.task,style=_props.style,running=_props.running,onDone=_props.onDone,onClick=_props.onClick,onMultiEdit=_props.onMultiEdit,onDelete=_props.onDelete,onAnnDelete=_props.onAnnDelete,onAnnModify=_props.onAnnModify,onDepDelete=_props.onDepDelete,onAnnAdd=_props.onAnnAdd,onStartStop=_props.onStartStop,onTap=_props.onTap,expanded=_props.expanded,layout=_props.layout;var _state=
this.state,dragTarget=_state.dragTarget,dependsVisible=_state.dependsVisible,collapsed=_state.collapsed;
var desc_field='description';
var multiline=[];
var fields=cols.map(function(item,idx){
if(item.field=='description'){
desc_field=item.full;
return _react2.default.createElement(widget.Div,{key:idx,style:(0,_main._l)(_main.styles.spacer),__source:{fileName:_jsxFileName,lineNumber:57}});
}
if(item.multiline){
var lines=task[item.full+'_lines'];
var _lines=lines.map(function(l,lidx){
var editBtn=void 0;
if(lidx==lines.length-1){
editBtn=
_react2.default.createElement(widget.IconBtn,{
icon:'pencil',
onClick:function onClick(e){
onMultiEdit(item.field,task[item.field],e);
},
title:item.label,__source:{fileName:_jsxFileName,lineNumber:65}});


};
return(
_react2.default.createElement(widget.Div,{
style:(0,_main._l)(_main.styles.hflex,_main.styles.annotation_line),
key:item.full+'-'+lidx,__source:{fileName:_jsxFileName,lineNumber:75}},

_react2.default.createElement(widget.Text,{
title:l,
style:[_main.styles.flex1,_main.styles.description,_main.styles.textSmall],__source:{fileName:_jsxFileName,lineNumber:79}},

l),

editBtn));


});

multiline.push(_lines);
return null;
};
var val=task[item.full+'_']||'';
var editable=task[item.field+'_ro']?false:true;
var onFieldClick=function onFieldClick(e){
if(item.field=='depends'&&task.dependsList){
_this2.toggleDepends();
};
};
return(
_react2.default.createElement(widget.Text,{
editable:editable,
width:item.width,
title:task[item.field+'_title'],
key:item.full,
onEdit:function onEdit(e){
e.field=item.field;
var edit_val=task[item.field+'_edit']||'';
onClick(e,edit_val);
},
onClick:onFieldClick,__source:{fileName:_jsxFileName,lineNumber:101}},

val));


});
var descSt=[_main.styles.description,_main.styles.flex1];
if(task.description_truncate){
descSt.push(_main.styles.oneLine);
}
var desc_count=null;
if(task.description_count){
desc_count=
_react2.default.createElement(widget.Text,{style:[_main.styles.description],__source:{fileName:_jsxFileName,lineNumber:124}},
task.description_count);


}
var depends=null;
if(dependsVisible&&task.dependsTasks){
depends=task.dependsTasks.map(function(item){
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.hflex,_main.styles.annotation_line),key:item.unique,__source:{fileName:_jsxFileName,lineNumber:133}},
_react2.default.createElement(widget.Text,{
title:item.description,
style:[_main.styles.flex1,_main.styles.description,_main.styles.textSmall,_main.styles.oneLine],__source:{fileName:_jsxFileName,lineNumber:134}},

item.id+' '+item.description),

_react2.default.createElement(widget.IconMenu,{style:style,__source:{fileName:_jsxFileName,lineNumber:140}},
_react2.default.createElement(widget.IconBtn,{
icon:'close',
onClick:function onClick(e){
onDepDelete(item.uuid,e);
},
title:'Remove dependency',__source:{fileName:_jsxFileName,lineNumber:141}}))));




});
};
var annotations=null;
var collapseBtn=void 0;
if(task.description_ann&&expanded){
var linesTotal=0;
task.description_ann.forEach(function(item){
var text=item.text||'';
var lines=text.split('\n');
linesTotal+=lines.length;
});
var collapsable=linesTotal>1;
if(collapsable){
var icon=collapsed?'expand':'compress';
collapseBtn=
_react2.default.createElement(widget.IconBtn,{
icon:icon,
onClick:function onClick(e){
_this2.toggleExpand();
},
title:'Toggle annotations collapse/expand',__source:{fileName:_jsxFileName,lineNumber:166}});


};
annotations=task.description_ann.map(function(item,idx){
var text=item.text||'';
var lines=text.split('\n');
if(collapsable&&collapsed&&lines.length>1){
text=lines[0].substr(0,77)+'...';
};
return(
_react2.default.createElement(widget.Div,{
style:(0,_main._l)(_main.styles.hflex,_main.styles.annotation_line),
key:item.unique,__source:{fileName:_jsxFileName,lineNumber:182}},

_react2.default.createElement(widget.Text,{
title:item.title,
style:[_main.styles.flex1,_main.styles.description,_main.styles.textSmall],
editable:true,
onEdit:function onEdit(e){
onAnnModify(item.origin,e);
},__source:{fileName:_jsxFileName,lineNumber:186}},

text),

_react2.default.createElement(widget.IconMenu,{style:style,__source:{fileName:_jsxFileName,lineNumber:196}},
_react2.default.createElement(widget.IconBtn,{
icon:'close',
onClick:function onClick(e){
onAnnDelete(item.origin,e);
},
title:'Remove annotation',__source:{fileName:_jsxFileName,lineNumber:197}}))));




});
};
var check_icon='square-o';
if(task.status=='completed'){
check_icon='check-square-o';
}
if(task.status=='deleted'){
check_icon='close';
}
if(task.status=='waiting'){
check_icon='clock-o';
}
if(task.status=='recurring'){
check_icon='refresh';
}
var taskStyles=[_main.styles.one_task];
if(dragTarget){
taskStyles.push(_main.styles.task_drop);
};
taskStyles=taskStyles.concat(style);
if(task.level>0){
taskStyles.push({
marginLeft:task.level*15});

};
var menuStyles=[_main.styles.task_menu].concat(style);
var expandedPart=void 0;
if(expanded){
expandedPart=
_react2.default.createElement(widget.Div,{__source:{fileName:_jsxFileName,lineNumber:236}},
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.hflex,_main.styles.wflex),__source:{fileName:_jsxFileName,lineNumber:237}},
fields),

multiline,
depends,
annotations);


};
return(
_react2.default.createElement(widget.Div,{
style:(0,_main._l)(taskStyles),
onClick:function onClick(e){
onTap(widget.eventInfo(e));
},
onDragEnter:this.onDragStart,
onDragLeave:this.onDragFinish,
onDragOver:this.onDragOver,
onDrop:this.onDrop,__source:{fileName:_jsxFileName,lineNumber:247}},

_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.hflex),__source:{fileName:_jsxFileName,lineNumber:257}},
_react2.default.createElement(widget.IconBtn,{
icon:check_icon,
onClick:onDone,__source:{fileName:_jsxFileName,lineNumber:258}}),

_react2.default.createElement(widget.Text,{
editable:true,
style:descSt,
onDrag:function onDrag(e){
return['tw/task',task.uuid,task.description];
},
onClick:function onClick(e){
if(e.meta){
e.stop();
onAnnAdd(e);
};
},
onEdit:function onEdit(e){
onClick(e,task.description);
},__source:{fileName:_jsxFileName,lineNumber:262}},

task[desc_field+'_']),

desc_count,
_react2.default.createElement(widget.IconMenu,{style:menuStyles,__source:{fileName:_jsxFileName,lineNumber:281}},
_react2.default.createElement(widget.IconBtn,{
icon:'close',
onClick:function onClick(e){
onDelete(e);
},
title:'Delete task',__source:{fileName:_jsxFileName,lineNumber:282}}),

_react2.default.createElement(widget.IconBtn,{
icon:'plus',
onClick:function onClick(e){
onAnnAdd(e);
},
title:'Add annotation',__source:{fileName:_jsxFileName,lineNumber:289}}),

_react2.default.createElement(widget.IconBtn,{
icon:running?'stop':'play',
onClick:function onClick(e){
onStartStop(e);
},
title:running?"Stop task":"Start task",__source:{fileName:_jsxFileName,lineNumber:296}})),


collapseBtn),

expandedPart));


}}]);return Task;}(widget.DnD);var


TaskPageCmp=function(_React$Component){_inherits(TaskPageCmp,_React$Component);

function TaskPageCmp(props){_classCallCheck(this,TaskPageCmp);var _this3=_possibleConstructorReturn(this,(TaskPageCmp.__proto__||Object.getPrototypeOf(TaskPageCmp)).call(this,
props));
_this3.state={};return _this3;

}_createClass(TaskPageCmp,[{key:'input',value:function input()

{
return this.refs.input.input();
}},{key:'filter',value:function filter(

_filter){
this.refs.input.filter(_filter);
}},{key:'renderTask',value:function renderTask(

item,idx,cols,info){var _this4=this;var _props2=







this.props,selection=_props2.selection,onEdit=_props2.onEdit,onSelect=_props2.onSelect,onAdd=_props2.onAdd,layout=_props2.layout,expanded=_props2.expanded;
var findTask=function findTask(uuid){
return info.tasks.find(function(t){return t.uuid==uuid;});
};
var running=item.start?true:false;
var onDone=function onDone(e){
if(e.longTap||e.meta){
onSelect(item);
e.stop&&e.stop();
return;
};
_this4.props.onDone(item);
};
var onAnnAdd=function onAnnAdd(e){
onEdit(item,'annotate','',false,true);
};
var onDelete=function onDelete(e){
onEdit(item,'delete','',true);
};
var onAnnDelete=function onAnnDelete(text,e){
onEdit(item,'denotate',text,true);
};
var onAnnModify=function onAnnModify(text,e){
onEdit(item,'reannotate',text,false,true);
};
var onClick=function onClick(e,data){var cmd=arguments.length>2&&arguments[2]!==undefined?arguments[2]:'modify';
if(e.meta){
var addCmd=data;
if(e.field=='id'){
addCmd='depends:'+(item.id||item.uuid);
}
onAdd(false,addCmd);
e.stop();
return;
}
onEdit(item,cmd,data);
};
var onTap=function onTap(e){
if(e.meta){
onSelect(item);
}
};
var onDepDelete=function onDepDelete(uuid,e){
var uuids=item.depends||[];
var dep=uuids.map(function(u){return u!=uuid?u:'-'+u;}).join(',');
onEdit(item,'modify','depends:'+dep,true);
};
var onDrop=function onDrop(type,data,e){
if(type=='tw/date'){
onEdit(item,'modify',data,true);
}
if(type=='tw/tag'){
onEdit(item,'modify','+'+data,true);
};
if(type=='tw/property'){
onEdit(item,'modify',data,true);
};
if(type=='tw/project'){
onEdit(item,'modify','pro:'+data,true);
};
if(type=='tw/task'){
var t=findTask(data);
if(!t)return;
var uuids=t.depends||[];
if(uuids.indexOf(item.uuid)!=-1||item.uuid==data){
return;
};
uuids.push(item.uuid);
onEdit(t,'modify','depends:'+uuids.join(','),true);
};
};
var onMultiEdit=function onMultiEdit(field,lines){
onEdit(item,field+':',lines,false,true);
};
var style=[_main.styles.one_item];
if(item.styles){
style.push.apply(style,item.styles);
};
if(selection[item.uuid]){
style.push(_main.styles.task_selected);
}
var key=(item.uuid||item.id)+'-'+idx;
return(
_react2.default.createElement(Task,{
task:item,
running:running,
style:style,
layout:layout,
expanded:expanded,
key:key,
cols:cols,
onDone:onDone,
onClick:onClick,
onMultiEdit:onMultiEdit,
onDelete:onDelete,
onAnnDelete:onAnnDelete,
onAnnModify:onAnnModify,
onAnnAdd:onAnnAdd,
onTap:onTap,
onStartStop:function onStartStop(e){
onEdit(item,running?'stop':'start','',true);
},
onDrop:onDrop,
onDepDelete:onDepDelete,__source:{fileName:_jsxFileName,lineNumber:419}}));



}},{key:'render',value:function render()

{var _props3=








this.props,info=_props3.info,selection=_props3.selection,onEdit=_props3.onEdit,onSelect=_props3.onSelect,onAdd=_props3.onAdd,loading=_props3.loading,expanded=_props3.expanded;
var body=null;
if(info){

var cols=info.cols.filter(function(item){
return item.visible;
});
var header_items=void 0;
if(expanded){
header_items=cols.map(function(item,idx){
if(item.multiline){
return null;
};
if(item.field=='description'){

return _react2.default.createElement(widget.Div,{key:idx,style:(0,_main._l)(_main.styles.spacer),__source:{fileName:_jsxFileName,lineNumber:469}});
}
return(
_react2.default.createElement(widget.Text,{
editable:false,
width:item.width,
key:idx,__source:{fileName:_jsxFileName,lineNumber:472}},

item.label));


});
};

body=this.renderBody(header_items,info);
}
var loadingIndicator=void 0;
if(loading){
loadingIndicator=_react2.default.createElement(widget.LoadingIndicator,{__source:{fileName:_jsxFileName,lineNumber:487}});
};
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vproxy,_main.styles.pane),__source:{fileName:_jsxFileName,lineNumber:490}},
_react2.default.createElement(widget.TaskPageInput,_extends({},
this.props,{
ref:'input',__source:{fileName:_jsxFileName,lineNumber:491}})),

_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vproxy,_main.styles.paneBody),__source:{fileName:_jsxFileName,lineNumber:495}},
body),

loadingIndicator));


}}]);return TaskPageCmp;}(_react2.default.Component);exports.TaskPageCmp=TaskPageCmp;var


CmdPageCmp=function(_React$Component2){_inherits(CmdPageCmp,_React$Component2);

function CmdPageCmp(props){_classCallCheck(this,CmdPageCmp);var _this5=_possibleConstructorReturn(this,(CmdPageCmp.__proto__||Object.getPrototypeOf(CmdPageCmp)).call(this,
props));
_this5.state={};return _this5;

}_createClass(CmdPageCmp,[{key:'input',value:function input()

{
return this.refs.input.input();
}},{key:'filter',value:function filter(

_filter2){
this.refs.input.filter(_filter2);
}},{key:'renderBody',value:function renderBody(

info){
return null;
}},{key:'render',value:function render()

{var _props4=



this.props,info=_props4.info,loading=_props4.loading;
var body=null;
body=this.renderBody(info);
var loadingIndicator=void 0;
if(loading){
loadingIndicator=_react2.default.createElement(widget.LoadingIndicator,{__source:{fileName:_jsxFileName,lineNumber:533}});
};
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vproxy,_main.styles.pane),__source:{fileName:_jsxFileName,lineNumber:536}},
_react2.default.createElement(widget.CmdPageInput,_extends({},
this.props,{
ref:'input',__source:{fileName:_jsxFileName,lineNumber:537}})),

_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vproxy,_main.styles.paneBody),__source:{fileName:_jsxFileName,lineNumber:541}},
body),

loadingIndicator));


}}]);return CmdPageCmp;}(_react2.default.Component);exports.CmdPageCmp=CmdPageCmp;var


Navigation=function(_React$Component3){_inherits(Navigation,_React$Component3);

function Navigation(props){_classCallCheck(this,Navigation);var _this6=_possibleConstructorReturn(this,(Navigation.__proto__||Object.getPrototypeOf(Navigation)).call(this,
props));
_this6.state={list:_this6.convert(props)};return _this6;
}_createClass(Navigation,[{key:'renderList',value:function renderList(

list){
return null;
}},{key:'convert',value:function convert(

props){
return[];
}},{key:'componentWillReceiveProps',value:function componentWillReceiveProps(

props){
this.setState({list:this.convert(props)});
}},{key:'render',value:function render()

{
if(!this.props.visible){
return null;
};
var list=this.state.list;
if(!list.length){

return null;
}var _props5=
this.props,title=_props5.title,onRefresh=_props5.onRefresh,onExpand=_props5.onExpand,compact=_props5.compact,expanded=_props5.expanded;
var expandBtn=void 0;
if(expanded===false||expanded===true){
expandBtn=
_react2.default.createElement(widget.IconBtn,{
icon:expanded?'compress':'expand',
title:'Collapse/expand list',
onClick:onExpand,__source:{fileName:_jsxFileName,lineNumber:582}});


};
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vflex,compact?_main.styles.flex0:_main.styles.flex1),__source:{fileName:_jsxFileName,lineNumber:590}},
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.hbar,_main.styles.paneTitle),__source:{fileName:_jsxFileName,lineNumber:591}},
_react2.default.createElement(widget.Text,{style:[_main.styles.flex1],__source:{fileName:_jsxFileName,lineNumber:592}},title),
expandBtn,
_react2.default.createElement(widget.IconBtn,{
icon:'refresh',
title:'Refresh list',
onClick:onRefresh,__source:{fileName:_jsxFileName,lineNumber:594}})),


this.renderList(list)));


}}]);return Navigation;}(_react2.default.Component);var


ProjectsNavigation=exports.ProjectsNavigation=function(_Navigation){_inherits(ProjectsNavigation,_Navigation);function ProjectsNavigation(){_classCallCheck(this,ProjectsNavigation);return _possibleConstructorReturn(this,(ProjectsNavigation.__proto__||Object.getPrototypeOf(ProjectsNavigation)).apply(this,arguments));}_createClass(ProjectsNavigation,[{key:'convert',value:function convert(

props){var
projects=props.projects,info=props.info;
var hilites={};
if(info&&info.tasks){
info.tasks.forEach(function(item){
if(item.project){
var val=hilites[item.project]||0;
hilites[item.project]=val+1;
}
});
};
var list=[];
var transformProjects=function transformProjects(arr){
arr.map(function(item,idx){
item.hilite=hilites[item.project];
item.index=idx;
return item;
}).forEach(function(item,idx){
list.push(item);
transformProjects(item.children);
});
};
transformProjects(projects);
return list;
}},{key:'render',value:function render()

{
var projects=this.state.list;
if(!projects.length||projects.length==1&&projects[0].project==''){

return null;
}
return _get(ProjectsNavigation.prototype.__proto__||Object.getPrototypeOf(ProjectsNavigation.prototype),'render',this).call(this);
}}]);return ProjectsNavigation;}(Navigation);var


UdaPane=exports.UdaPane=function(_Navigation2){_inherits(UdaPane,_Navigation2);function UdaPane(){_classCallCheck(this,UdaPane);return _possibleConstructorReturn(this,(UdaPane.__proto__||Object.getPrototypeOf(UdaPane)).apply(this,arguments));}_createClass(UdaPane,[{key:'convert',value:function convert(

props){var
info=props.info,config=props.config;
var hilites={};
if(info&&info.tasks){
info.tasks.forEach(function(item){
hilites[item[config.id]||'']=true;
});
};
return config.values.map(function(item,idx){
return{
hilite:hilites[item],
index:idx,
name:item};

});
}}]);return UdaPane;}(Navigation);var



TagsNavigation=exports.TagsNavigation=function(_Navigation3){_inherits(TagsNavigation,_Navigation3);function TagsNavigation(){_classCallCheck(this,TagsNavigation);return _possibleConstructorReturn(this,(TagsNavigation.__proto__||Object.getPrototypeOf(TagsNavigation)).apply(this,arguments));}_createClass(TagsNavigation,[{key:'convert',value:function convert(

props){var
info=props.info,tags=props.tags;
var hilites={};
if(info&&info.tasks){
info.tasks.forEach(function(item){
if(item.tags){
item.tags.forEach(function(tag){
var val=hilites[tag]||0;
hilites[tag]=val+1;
});
}
});
};
return tags.map(function(item,idx){
item.hilite=hilites[item.name];
item.index=idx;
return item;
});
}}]);return TagsNavigation;}(Navigation);var



ReportsList=exports.ReportsList=function(_Navigation4){_inherits(ReportsList,_Navigation4);function ReportsList(){_classCallCheck(this,ReportsList);return _possibleConstructorReturn(this,(ReportsList.__proto__||Object.getPrototypeOf(ReportsList)).apply(this,arguments));}_createClass(ReportsList,[{key:'convert',value:function convert(
props){
return props.reports;
}}]);return ReportsList;}(Navigation);var


ContextsList=exports.ContextsList=function(_Navigation5){_inherits(ContextsList,_Navigation5);function ContextsList(){_classCallCheck(this,ContextsList);return _possibleConstructorReturn(this,(ContextsList.__proto__||Object.getPrototypeOf(ContextsList)).apply(this,arguments));}_createClass(ContextsList,[{key:'convert',value:function convert(
props){
return props.contexts||[];
}}]);return ContextsList;}(Navigation);var


CalendarPane=exports.CalendarPane=function(_React$Component4){_inherits(CalendarPane,_React$Component4);

function CalendarPane(props){_classCallCheck(this,CalendarPane);var _this12=_possibleConstructorReturn(this,(CalendarPane.__proto__||Object.getPrototypeOf(CalendarPane)).call(this,
props));
_this12.state={};return _this12;

}_createClass(CalendarPane,[{key:'render',value:function render()

{var _props6=
this.props,title=_props6.title,data=_props6.data,onChange=_props6.onChange,_onClick=_props6.onClick,onDrag=_props6.onDrag;
var header=
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vflex),__source:{fileName:_jsxFileName,lineNumber:712}},
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.hbar,_main.styles.paneTitle),__source:{fileName:_jsxFileName,lineNumber:713}},
_react2.default.createElement(widget.Text,{
style:[_main.styles.flex1],
onClick:function onClick(e){
onChange(0);
},
title:'Jump to current month',__source:{fileName:_jsxFileName,lineNumber:714}},

title),

_react2.default.createElement(widget.IconBtn,{
icon:'chevron-left',
title:'Month before',
onClick:function onClick(e){
return onChange(-1,e.meta);
},__source:{fileName:_jsxFileName,lineNumber:723}}),

_react2.default.createElement(widget.IconBtn,{
icon:'chevron-right',
title:'Next month',
onClick:function onClick(e){
return onChange(1,e.meta);
},__source:{fileName:_jsxFileName,lineNumber:730}})));




var weeks=data.map(function(week,widx){
var days=week.map(function(day,didx){
var style=[_main.styles.flex1,_main.styles.calendar_day,_main.styles.textSmall];
if(!day.active)style.push(_main.styles.calendar_passive);
if(day.weekend)style.push(_main.styles.calendar_weekend);
return(
_react2.default.createElement(widget.CalendarItem,{
key:didx,
style:style,
value:day.date,
onDrag:onDrag,
onClick:function onClick(e){
_onClick(day.date,e.meta);
},__source:{fileName:_jsxFileName,lineNumber:746}},

day.day));


});
return(
_react2.default.createElement(widget.Div,{key:widx,style:(0,_main._l)(_main.styles.hflex,_main.styles.calendar_week),__source:{fileName:_jsxFileName,lineNumber:760}},
days));


});
return(
_react2.default.createElement(widget.Div,{__source:{fileName:_jsxFileName,lineNumber:766}},
header,
weeks));


}}]);return CalendarPane;}(_react2.default.Component);