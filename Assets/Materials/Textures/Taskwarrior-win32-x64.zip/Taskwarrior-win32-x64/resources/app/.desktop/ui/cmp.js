'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.CalendarCmp=exports.StatusbarCmp=exports.CmdPageCmp=exports.TaskPageCmp=exports.MainCmp=exports.ReportsCmp=exports.NavigationCmp=exports.UdaPaneCmp=exports.CenterCmp=exports.ToolbarCmp=exports.AppCmp=exports.calculateLayout=undefined;var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _jsxFileName='C:\\Users\\Michael\\src\\task\\app\\ui\\cmp.desktop.js';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _react=require('react');var _react2=_interopRequireDefault(_react);
var _main=require('../styles/main');
var _widget=require('./widget');var widget=_interopRequireWildcard(_widget);
var _cmp=require('./cmp.common');var common=_interopRequireWildcard(_cmp);function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}else{var newObj={};if(obj!=null){for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key))newObj[key]=obj[key];}}newObj.default=obj;return newObj;}}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var _require=

require('electron'),ipcRenderer=_require.ipcRenderer;
var path=require('path');
























var calculateLayout=exports.calculateLayout=function calculateLayout(){
return{};
};var

AppCmp=exports.AppCmp=function(_React$Component){_inherits(AppCmp,_React$Component);function AppCmp(){_classCallCheck(this,AppCmp);return _possibleConstructorReturn(this,(AppCmp.__proto__||Object.getPrototypeOf(AppCmp)).apply(this,arguments));}_createClass(AppCmp,[{key:'render',value:function render()

{
return(
_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.vproxy,_main.styles.max,_main.styles.app]),__source:{fileName:_jsxFileName,lineNumber:40}},
this.props.children));


}}]);return AppCmp;}(_react2.default.Component);
;var

ToolbarCmp=exports.ToolbarCmp=function(_React$Component2){_inherits(ToolbarCmp,_React$Component2);function ToolbarCmp(){_classCallCheck(this,ToolbarCmp);return _possibleConstructorReturn(this,(ToolbarCmp.__proto__||Object.getPrototypeOf(ToolbarCmp)).apply(this,arguments));}_createClass(ToolbarCmp,[{key:'render',value:function render()

{var _props=





this.props,onCommand=_props.onCommand,onTogglePane=_props.onTogglePane,onSync=_props.onSync,onUndo=_props.onUndo;
return(
_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.flex0,_main.styles.toolbar,_main.styles.hflex]),__source:{fileName:_jsxFileName,lineNumber:57}},
_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.flex0,_main.styles.hbar]),__source:{fileName:_jsxFileName,lineNumber:58}},
_react2.default.createElement(widget.IconBtn,{
icon:'navicon',
title:'Toggle Projects and Tags pane',
onClick:function onClick(e){
onTogglePane('left',e);
},__source:{fileName:_jsxFileName,lineNumber:59}})),


_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.flex1,_main.styles.hbar]),__source:{fileName:_jsxFileName,lineNumber:67}}),

_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.flex0,_main.styles.hbar]),__source:{fileName:_jsxFileName,lineNumber:69}},
_react2.default.createElement(widget.IconBtn,{
icon:'terminal',
title:'Run custom task command',
onClick:onCommand,__source:{fileName:_jsxFileName,lineNumber:70}}),

_react2.default.createElement(widget.IconBtn,{
icon:'undo',
title:'Undo latest operation',
onClick:onUndo,__source:{fileName:_jsxFileName,lineNumber:75}}),

_react2.default.createElement(widget.IconBtn,{
icon:'cloud',
title:'Sync with taskd server',
onClick:onSync,__source:{fileName:_jsxFileName,lineNumber:80}}),

_react2.default.createElement(widget.IconBtn,{
icon:'navicon',
title:'Toggle Reports and Contexts pane',
onClick:function onClick(e){
onTogglePane('right',e);
},__source:{fileName:_jsxFileName,lineNumber:85}}))));




}}]);return ToolbarCmp;}(_react2.default.Component);
;var

CenterCmp=exports.CenterCmp=function(_React$Component3){_inherits(CenterCmp,_React$Component3);function CenterCmp(){_classCallCheck(this,CenterCmp);return _possibleConstructorReturn(this,(CenterCmp.__proto__||Object.getPrototypeOf(CenterCmp)).apply(this,arguments));}_createClass(CenterCmp,[{key:'render',value:function render()

{
return(
_react2.default.createElement('div',{style:(0,_main._l)([_main.styles.hproxy,_main.styles.center]),__source:{fileName:_jsxFileName,lineNumber:102}},
this.props.children));


}}]);return CenterCmp;}(_react2.default.Component);
;var

PaneCmp=function(_React$Component4){_inherits(PaneCmp,_React$Component4);

function PaneCmp(props,name){_classCallCheck(this,PaneCmp);var _this4=_possibleConstructorReturn(this,(PaneCmp.__proto__||Object.getPrototypeOf(PaneCmp)).call(this,
props));
_this4.onMouseLeave=_this4.onMouseLeave.bind(_this4);
_this4.name=name;return _this4;
}_createClass(PaneCmp,[{key:'paneConfig',value:function paneConfig(

field){
return{
visible:this.props[field]!=='hidden',
compact:this.props[field]==='compact'};

}},{key:'onMouseLeave',value:function onMouseLeave(

e){var _props2=
this.props,mode=_props2.mode,onHide=_props2.onHide;
if(mode=='float'){
onHide(this.name);
};
}},{key:'renderExtra',value:function renderExtra()

{
return this.props.extra.map(function(item,idx){
return(
_react2.default.createElement('div',{key:idx,style:(0,_main._l)(_main.styles.flex0),__source:{fileName:_jsxFileName,lineNumber:134}},
item));


});
}}]);return PaneCmp;}(_react2.default.Component);var


ProjectsNavigation=function(_common$ProjectsNavig){_inherits(ProjectsNavigation,_common$ProjectsNavig);function ProjectsNavigation(){_classCallCheck(this,ProjectsNavigation);return _possibleConstructorReturn(this,(ProjectsNavigation.__proto__||Object.getPrototypeOf(ProjectsNavigation)).apply(this,arguments));}_createClass(ProjectsNavigation,[{key:'renderList',value:function renderList(

list){var _props3=
this.props,_onClick=_props3.onClick,_onEdit=_props3.onEdit,compact=_props3.compact;
var projects=list.map(function(item,idx){
var prefix='';
for(var i=0;i<item.indent;i++){
prefix+=' ';
}
var st=[_main.styles.one_nav,_main.styles.hflex,_main.styles.hbar];
if(item.hilite)st.push(_main.styles.hilite);
return(
_react2.default.createElement('div',{
key:item.project,
style:(0,_main._l)(st),
onDragStart:function onDragStart(e){
e.dataTransfer.setData('text/plain','pro:'+item.project);
e.dataTransfer.setData('tw/project',item.project);
},
draggable:true,
onClick:function onClick(evt){
var e=widget.eventInfo(evt);
_onClick(item,e.meta);
},__source:{fileName:_jsxFileName,lineNumber:154}},

_react2.default.createElement(widget.Text,{
style:[_main.styles.flex1],
editable:true,
onEdit:function onEdit(e){
e.stop();
_onEdit(item);
},__source:{fileName:_jsxFileName,lineNumber:167}},

prefix+item.name),

_react2.default.createElement(widget.Text,{style:[_main.styles.flex0],__source:{fileName:_jsxFileName,lineNumber:177}},item.count)));


});
return(
_react2.default.createElement('div',{style:(0,_main._l)(compact?_main.styles.flex0:_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:182}},
projects));


}}]);return ProjectsNavigation;}(common.ProjectsNavigation);var


UdaPaneCmp=exports.UdaPaneCmp=function(_common$UdaPane){_inherits(UdaPaneCmp,_common$UdaPane);function UdaPaneCmp(){_classCallCheck(this,UdaPaneCmp);return _possibleConstructorReturn(this,(UdaPaneCmp.__proto__||Object.getPrototypeOf(UdaPaneCmp)).apply(this,arguments));}_createClass(UdaPaneCmp,[{key:'renderList',value:function renderList(

list){var _props4=
this.props,_onClick2=_props4.onClick,compact=_props4.compact,config=_props4.config;
var items=list.map(function(item,idx){
var st=[_main.styles.one_nav,_main.styles.hflex,_main.styles.hbar];
if(item.hilite)st.push(_main.styles.hilite);
var value=config.id+':'+item.name;
return(
_react2.default.createElement('div',{
key:item.name,
style:(0,_main._l)(st),
onClick:function onClick(evt){
var e=widget.eventInfo(evt);
_onClick2(value,e.meta);
},
onDragStart:function onDragStart(e){
e.dataTransfer.setData('text/plain',value);
e.dataTransfer.setData('tw/property',value);
},
draggable:true,__source:{fileName:_jsxFileName,lineNumber:198}},

_react2.default.createElement(widget.Text,{
style:[_main.styles.flex1],__source:{fileName:_jsxFileName,lineNumber:211}},

item.name||'(none)')));



});
return(
_react2.default.createElement('div',{style:(0,_main._l)(compact?_main.styles.flex0:_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:220}},
items));


}}]);return UdaPaneCmp;}(common.UdaPane);var


TagsNavigation=function(_common$TagsNavigatio){_inherits(TagsNavigation,_common$TagsNavigatio);function TagsNavigation(){_classCallCheck(this,TagsNavigation);return _possibleConstructorReturn(this,(TagsNavigation.__proto__||Object.getPrototypeOf(TagsNavigation)).apply(this,arguments));}_createClass(TagsNavigation,[{key:'renderList',value:function renderList(

list){var _props5=
this.props,_onClick3=_props5.onClick,_onEdit2=_props5.onEdit,compact=_props5.compact;
var tags=list.map(function(item,idx){
var st=[_main.styles.one_nav,_main.styles.hflex,_main.styles.hbar];
if(item.hilite)st.push(_main.styles.hilite);
return(
_react2.default.createElement('div',{
key:item.name,
style:(0,_main._l)(st),
onClick:function onClick(evt){
var e=widget.eventInfo(evt);
_onClick3(item,e.meta);
},
onDragStart:function onDragStart(e){
e.dataTransfer.setData('text/plain','+'+item.name);
e.dataTransfer.setData('tw/tag',item.name);
},
draggable:true,__source:{fileName:_jsxFileName,lineNumber:235}},

_react2.default.createElement(widget.Text,{
style:[_main.styles.flex1],
editable:true,
onEdit:function onEdit(e){
e.stop();
_onEdit2(item);
},__source:{fileName:_jsxFileName,lineNumber:248}},

item.name),

_react2.default.createElement(widget.Text,{style:[_main.styles.flex0],__source:{fileName:_jsxFileName,lineNumber:258}},item.count)));


});
return(
_react2.default.createElement('div',{style:(0,_main._l)(compact?_main.styles.flex0:_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:263}},
tags));


}}]);return TagsNavigation;}(common.TagsNavigation);var


NavigationCmp=exports.NavigationCmp=function(_PaneCmp){_inherits(NavigationCmp,_PaneCmp);

function NavigationCmp(props){_classCallCheck(this,NavigationCmp);return _possibleConstructorReturn(this,(NavigationCmp.__proto__||Object.getPrototypeOf(NavigationCmp)).call(this,
props,'left'));
}_createClass(NavigationCmp,[{key:'render',value:function render()

{
var st=[_main.styles.navigation,_main.styles.vflex];var _props6=
this.props,mode=_props6.mode,udaPanels=_props6.udaPanels;
if(mode=='hidden'){
return null;
};
var pane=
_react2.default.createElement('div',{style:(0,_main._l)(st),onMouseLeave:this.onMouseLeave,__source:{fileName:_jsxFileName,lineNumber:283}},
this.renderExtra(),
_react2.default.createElement(ProjectsNavigation,_extends({
title:'Projects'},
this.paneConfig('projectsMode'),{
onRefresh:this.props.onRefreshProjects,
onClick:this.props.onProjectClick,
onEdit:this.props.onProjectEdit,
projects:this.props.projects||[],
expanded:this.props.projectsExpanded,
onExpand:this.props.onExpandProjects,
info:this.props.info,__source:{fileName:_jsxFileName,lineNumber:285}})),

_react2.default.createElement(TagsNavigation,_extends({
title:'Tags'},
this.paneConfig('tagsMode'),{
onRefresh:this.props.onRefreshTags,
onClick:this.props.onTagClick,
onEdit:this.props.onTagEdit,
tags:this.props.tags||[],
expanded:this.props.tagsExpanded,
onExpand:this.props.onExpandTags,
info:this.props.info,__source:{fileName:_jsxFileName,lineNumber:296}})),

udaPanels);


if(mode=='float'){
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.float_pane),__source:{fileName:_jsxFileName,lineNumber:312}},
pane,
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.float_space,_main.styles.flex1),__source:{fileName:_jsxFileName,lineNumber:314}})));


};
return pane;
}}]);return NavigationCmp;}(PaneCmp);
;var

ContextsList=function(_common$ContextsList){_inherits(ContextsList,_common$ContextsList);function ContextsList(){_classCallCheck(this,ContextsList);return _possibleConstructorReturn(this,(ContextsList.__proto__||Object.getPrototypeOf(ContextsList)).apply(this,arguments));}_createClass(ContextsList,[{key:'renderList',value:function renderList(

list){var _props7=
this.props,onRefresh=_props7.onRefresh,onClick=_props7.onClick,compact=_props7.compact;
var items=list.map(function(item,idx){
var click=function click(){
onClick(item.context);
};
return(
_react2.default.createElement(widget.Div,{
style:(0,_main._l)(_main.styles.one_nav,item.selected?_main.styles.hilite:null),
key:idx,
onClick:click,__source:{fileName:_jsxFileName,lineNumber:331}},

_react2.default.createElement(widget.Text,{style:[_main.styles.oneLine],__source:{fileName:_jsxFileName,lineNumber:336}},item.name),
_react2.default.createElement(widget.Text,{style:[_main.styles.oneLine,_main.styles.textSmall],__source:{fileName:_jsxFileName,lineNumber:337}},item.filter)));


});
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(_main.styles.vflex,compact?_main.styles.flex0:_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:342}},
items));


}}]);return ContextsList;}(common.ContextsList);var


ReportsListItem=function(_widget$DnD){_inherits(ReportsListItem,_widget$DnD);

function ReportsListItem(props){_classCallCheck(this,ReportsListItem);var _this10=_possibleConstructorReturn(this,(ReportsListItem.__proto__||Object.getPrototypeOf(ReportsListItem)).call(this,
props));
_this10.dropTypes.push('tw/tag','tw/project');
_this10.state={};return _this10;
}_createClass(ReportsListItem,[{key:'onDropHandler',value:function onDropHandler(

type,data){
this.props.onDrop(type,data);
}},{key:'render',value:function render()

{var _props8=
this.props,onClick=_props8.onClick,item=_props8.item;var
dragTarget=this.state.dragTarget;
return(
_react2.default.createElement(widget.Div,{
onDragEnter:this.onDragStart,
onDragLeave:this.onDragFinish,
onDragOver:this.onDragOver,
onDrop:this.onDrop,
style:(0,_main._l)(_main.styles.one_nav,dragTarget?_main.styles.task_drop:null),
onClick:onClick,__source:{fileName:_jsxFileName,lineNumber:365}},

_react2.default.createElement(widget.Text,{style:[_main.styles.oneLine],__source:{fileName:_jsxFileName,lineNumber:373}},item.name),
_react2.default.createElement(widget.Text,{style:[_main.styles.oneLine,_main.styles.textSmall],__source:{fileName:_jsxFileName,lineNumber:374}},item.title)));


}}]);return ReportsListItem;}(widget.DnD);var


ReportsList=function(_common$ReportsList){_inherits(ReportsList,_common$ReportsList);function ReportsList(){_classCallCheck(this,ReportsList);return _possibleConstructorReturn(this,(ReportsList.__proto__||Object.getPrototypeOf(ReportsList)).apply(this,arguments));}_createClass(ReportsList,[{key:'renderList',value:function renderList(

list){var _this12=this;var
compact=this.props.compact;
var reports=list.map(function(item,idx){
var onClick=function onClick(){
_this12.props.onClick(item);
};
var onDrop=function onDrop(type,data){
_this12.props.onClick(item,type,data);
};
return(
_react2.default.createElement(ReportsListItem,{
key:idx,
onDrop:onDrop,
onClick:onClick,
item:item,__source:{fileName:_jsxFileName,lineNumber:392}}));


});
return(
_react2.default.createElement(widget.Div,{style:(0,_main._l)(compact?_main.styles.flex0:_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:401}},
reports));


}}]);return ReportsList;}(common.ReportsList);var



ReportsCmp=exports.ReportsCmp=function(_PaneCmp2){_inherits(ReportsCmp,_PaneCmp2);

function ReportsCmp(props){_classCallCheck(this,ReportsCmp);return _possibleConstructorReturn(this,(ReportsCmp.__proto__||Object.getPrototypeOf(ReportsCmp)).call(this,
props,'right'));
}_createClass(ReportsCmp,[{key:'render',value:function render()

{var _props9=










this.props,reports=_props9.reports,onReportsRefresh=_props9.onReportsRefresh,onReportClick=_props9.onReportClick,reportsExpanded=_props9.reportsExpanded,onExpandReports=_props9.onExpandReports,mode=_props9.mode,contexts=_props9.contexts,onContextsRefresh=_props9.onContextsRefresh,onContextClick=_props9.onContextClick;
if(mode=='hidden'){
return null;
};
var st=[_main.styles.right_pane,_main.styles.reports,_main.styles.vflex,_main.styles.flex0];
var onClick=function onClick(item,type,data){
var filter='';
if(type=='tw/tag'&&data){
filter='+'+data;
};
if(type=='tw/project'&&data){
filter='pro:'+data;
};
onReportClick(item,filter);
};
var pane=
_react2.default.createElement('div',{style:(0,_main._l)(st),onMouseLeave:this.onMouseLeave,__source:{fileName:_jsxFileName,lineNumber:442}},
this.renderExtra(),
_react2.default.createElement(ReportsList,_extends({
title:'Reports'},
this.paneConfig('reportsMode'),{
style:_main.styles.flex1,
reports:reports,
onRefresh:onReportsRefresh,
onClick:onClick,
expanded:reportsExpanded,
onExpand:onExpandReports,__source:{fileName:_jsxFileName,lineNumber:444}})),

_react2.default.createElement(ContextsList,_extends({},
this.paneConfig('contextsMode'),{
title:'Contexts',
style:_main.styles.flex0,
contexts:contexts,
onRefresh:onContextsRefresh,
onClick:onContextClick,__source:{fileName:_jsxFileName,lineNumber:454}})));



if(mode=='float'){
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.float_pane),__source:{fileName:_jsxFileName,lineNumber:466}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.float_space,_main.styles.flex1),__source:{fileName:_jsxFileName,lineNumber:467}}),
pane));


}
return pane;
}}]);return ReportsCmp;}(PaneCmp);
;var

PopupEditor=function(_React$Component5){_inherits(PopupEditor,_React$Component5);

function PopupEditor(props){_classCallCheck(this,PopupEditor);var _this14=_possibleConstructorReturn(this,(PopupEditor.__proto__||Object.getPrototypeOf(PopupEditor)).call(this,
props));
_this14.state={
input:props.input||''};return _this14;

}_createClass(PopupEditor,[{key:'reset',value:function reset()

{
this.setState({
input:this.props.input});

}},{key:'onChange',value:function onChange(

evt){
this.setState({
input:evt.target.value});

}},{key:'finish',value:function finish(

success,e){
var input=this.state.input.trim();
if(success)
this.props.onDone(input,e);else

this.props.onCancel(input,e);
}},{key:'onKey',value:function onKey(

evt){
var e=widget.eventInfo(evt);
if(e.key==13){
this.finish(true,e);
}
if(e.key==27){
this.finish(false,e);
}
}},{key:'onTAKey',value:function onTAKey(

evt){
var e=widget.eventInfo(evt);
if(e.key==13&&e.ctrl){
this.finish(true,{});
}
if(e.key==27&&e.ctrl){
this.finish(false,{});
}
}},{key:'componentDidMount',value:function componentDidMount()

{
this.refs.input.focus();
}},{key:'render',value:function render()

{var _this15=this;
var input=void 0;
var lineStyle=void 0;var _props10=
this.props,title=_props10.title,multiline=_props10.multiline;
if(multiline){
lineStyle=[_main.styles.hflex,_main.styles.wflex];
input=
_react2.default.createElement('textarea',{
style:(0,_main._l)(_main.styles.inp,_main.styles.flex1),
value:this.state.input,
onChange:this.onChange.bind(this),
rows:_main.styles.multiline.rows,
onKeyDown:this.onTAKey.bind(this),
ref:'input',__source:{fileName:_jsxFileName,lineNumber:536}});


}else{
lineStyle=[_main.styles.hflex,_main.styles.hbar,_main.styles.wflex];
input=
_react2.default.createElement('input',{
style:(0,_main._l)(_main.styles.inp,_main.styles.flex1),
type:'search',
value:this.state.input,
onChange:this.onChange.bind(this),
onKeyDown:this.onKey.bind(this),
ref:'input',__source:{fileName:_jsxFileName,lineNumber:548}});


};
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.floatCenter),__source:{fileName:_jsxFileName,lineNumber:559}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.input_box),__source:{fileName:_jsxFileName,lineNumber:560}},
_react2.default.createElement('div',{style:(0,_main._l)(lineStyle),__source:{fileName:_jsxFileName,lineNumber:561}},
_react2.default.createElement(widget.Text,{__source:{fileName:_jsxFileName,lineNumber:562}},this.props.title),
input),

_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.hflex),__source:{fileName:_jsxFileName,lineNumber:565}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.spacer),__source:{fileName:_jsxFileName,lineNumber:566}}),
_react2.default.createElement(widget.IconBtn,{icon:'check',onClick:function onClick(e){
_this15.finish(true,e);
},__source:{fileName:_jsxFileName,lineNumber:567}}),
_react2.default.createElement(widget.IconBtn,{icon:'close',onClick:function onClick(e){
_this15.finish(false,e);
},__source:{fileName:_jsxFileName,lineNumber:570}})))));




}}]);return PopupEditor;}(_react2.default.Component);var



MainCmp=exports.MainCmp=function(_React$Component6){_inherits(MainCmp,_React$Component6);

function MainCmp(props){_classCallCheck(this,MainCmp);var _this16=_possibleConstructorReturn(this,(MainCmp.__proto__||Object.getPrototypeOf(MainCmp)).call(this,
props));
_this16.state={};return _this16;

}_createClass(MainCmp,[{key:'showInput',value:function showInput(

title,input,context){
this.setState({
input:{
title:title,input:input,context:context}});


}},{key:'onInputCancel',value:function onInputCancel()

{
this.setState({
input:undefined});

}},{key:'showPopup',value:function showPopup(

css,data,config){
ipcRenderer.send('popup-open',css,data,config);
}},{key:'updatePopup',value:function updatePopup(

data){
ipcRenderer.send('popup-update',data);
}},{key:'onInputDone',value:function onInputDone(

input,e){var keepOpen,success;return regeneratorRuntime.async(function onInputDone$(_context){while(1){switch(_context.prev=_context.next){case 0:
keepOpen=e.ctrl;_context.next=3;return regeneratorRuntime.awrap(
this.props.onInput(input,this.state.input.context));case 3:success=_context.sent;if(!
success){_context.next=10;break;}if(!
keepOpen){_context.next=8;break;}
this.refs.popup_input.reset();return _context.abrupt('return');case 8:

;
this.setState({
input:undefined});case 10:

;case 11:case'end':return _context.stop();}}},null,this);}},{key:'render',value:function render()


{var _props11=
this.props,pages=_props11.pages,pins=_props11.pins,page=_props11.page,onNavigation=_props11.onNavigation;var
input=this.state.input;
var pageCmps=pages.map(function(pageCmp,idx){
if(pageCmp.key==page){
return _react2.default.createElement('div',{key:pageCmp.key,style:(0,_main._l)(_main.styles.vproxy),__source:{fileName:_jsxFileName,lineNumber:630}},pageCmp.cmp);
}else{
return _react2.default.createElement('div',{key:pageCmp.key,style:(0,_main._l)(_main.styles.none),__source:{fileName:_jsxFileName,lineNumber:632}},pageCmp.cmp);
};
});
var pinsCmps=pins.map(function(pageCmp,idx){
return _react2.default.createElement('div',{key:pageCmp.key,style:(0,_main._l)(_main.styles.vproxy),__source:{fileName:_jsxFileName,lineNumber:636}},pageCmp.cmp);
});
var pageIndicators=pages.map(function(pageCmp,idx){
var icn=pageCmp.key==page?'circle':'circle-o';
return _react2.default.createElement('i',{key:idx,className:'fa fa-fw fa-'+icn,__source:{fileName:_jsxFileName,lineNumber:640}});
});
var inputCmp=null;
if(input){
inputCmp=
_react2.default.createElement(PopupEditor,{
input:input.input,
title:input.title,
multiline:input.context.multiline,
onDone:this.onInputDone.bind(this),
onCancel:this.onInputCancel.bind(this),
ref:'popup_input',__source:{fileName:_jsxFileName,lineNumber:645}});


};
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.vproxy,_main.styles.tasks),__source:{fileName:_jsxFileName,lineNumber:656}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex1,_main.styles.hflex),__source:{fileName:_jsxFileName,lineNumber:657}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.vproxy),__source:{fileName:_jsxFileName,lineNumber:658}},
pageCmps),

pinsCmps),

_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.hbar),__source:{fileName:_jsxFileName,lineNumber:663}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hbar),__source:{fileName:_jsxFileName,lineNumber:664}},
_react2.default.createElement(widget.IconBtn,{icon:'chevron-left',onClick:function onClick(){
onNavigation(-1);
},__source:{fileName:_jsxFileName,lineNumber:665}})),

_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex1,_main.styles.textCenter,_main.styles.textSmall),__source:{fileName:_jsxFileName,lineNumber:669}},
pageIndicators),

_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hbar),__source:{fileName:_jsxFileName,lineNumber:672}},
_react2.default.createElement(widget.IconBtn,{icon:'chevron-right',onClick:function onClick(){
onNavigation(1);
},__source:{fileName:_jsxFileName,lineNumber:673}}))),


inputCmp));


}}]);return MainCmp;}(_react2.default.Component);
;var

TaskPageCmp=exports.TaskPageCmp=function(_common$TaskPageCmp){_inherits(TaskPageCmp,_common$TaskPageCmp);

function TaskPageCmp(props){_classCallCheck(this,TaskPageCmp);return _possibleConstructorReturn(this,(TaskPageCmp.__proto__||Object.getPrototypeOf(TaskPageCmp)).call(this,
props));
}_createClass(TaskPageCmp,[{key:'renderBody',value:function renderBody(

header,info){var _this18=this;
var cols=info.cols.filter(function(item){
return item.visible;
});
var _tasks=info.tasks.map(function(item,idx){
return _this18.renderTask(item,idx,cols,info);
});
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.vproxy),__source:{fileName:_jsxFileName,lineNumber:698}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.wflex),__source:{fileName:_jsxFileName,lineNumber:699}},header),
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex1s),__source:{fileName:_jsxFileName,lineNumber:700}},_tasks)));


}}]);return TaskPageCmp;}(common.TaskPageCmp);var



CmdPageCmp=exports.CmdPageCmp=function(_common$CmdPageCmp){_inherits(CmdPageCmp,_common$CmdPageCmp);

function CmdPageCmp(props){_classCallCheck(this,CmdPageCmp);return _possibleConstructorReturn(this,(CmdPageCmp.__proto__||Object.getPrototypeOf(CmdPageCmp)).call(this,
props));
}_createClass(CmdPageCmp,[{key:'renderBody',value:function renderBody(

info){
var lines=(info?info.lines:[]).map(function(line,idx){
return(
_react2.default.createElement(widget.Text,{
key:idx,
style:[_main.styles.pre,_main.styles['cmdLine_'+line.type]],__source:{fileName:_jsxFileName,lineNumber:716}},

line.line));


});
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.vproxy,_main.styles.relative),__source:{fileName:_jsxFileName,lineNumber:725}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.cmdPane),__source:{fileName:_jsxFileName,lineNumber:726}},lines)));


}}]);return CmdPageCmp;}(common.CmdPageCmp);var



StatusbarCmp=exports.StatusbarCmp=function(_React$Component7){_inherits(StatusbarCmp,_React$Component7);

function StatusbarCmp(props){_classCallCheck(this,StatusbarCmp);var _this20=_possibleConstructorReturn(this,(StatusbarCmp.__proto__||Object.getPrototypeOf(StatusbarCmp)).call(this,
props));
_this20.state={
message:'',
floats:[]};return _this20;

}_createClass(StatusbarCmp,[{key:'hideFloat',value:function hideFloat(

fl){var _this21=this;
this.state.floats.forEach(function(item,idx){
if(item==fl){
_this21.state.floats.splice(idx,1);
_this21.setState({
floats:_this21.state.floats});

};
});
}},{key:'showMessage',value:function showMessage(

type,message,choices,resp){var _this22=this;
if(!message){
return false;
}
if(type=='question'){
var fl={
type:type,
message:message,
choices:choices,
resp:resp};

this.state.floats.push(fl);
this.setState({
floats:this.state.floats});

return;
}var
foreground=this.props.foreground;
if(!foreground){
var notification=new Notification('Taskwarrior',{
body:message,
icon:path.join(__dirname,'../../desktop/res/icon.png')});

notification.onClick=function(){
ipcRenderer.send('raise');
};
};
this.setState({
type:type,
message:message,
time:new Date()});

if(type=='error'){
var _fl={
type:type,
message:message};

this.state.floats.push(_fl);
this.setState({
floats:this.state.floats});

setTimeout(function(){
_this22.hideFloat(_fl);
},2000);
};
}},{key:'render',value:function render()

{var _this23=this;var
spin=this.props.spin;
var spinCls='fa fa-fw fa-cloud';
if(spin)spinCls+=' fa-spin';
var floats=this.state.floats.map(function(item,idx){
if(item.type=='question'){
var btns=item.choices.map(function(btn){
return(
_react2.default.createElement('a',{
key:btn,
href:'#',
style:(0,_main._l)(_main.styles.btn_a),
onClick:function onClick(e){
_this23.hideFloat(item);
item.resp(btn);
},__source:{fileName:_jsxFileName,lineNumber:809}},

btn));


});
return(
_react2.default.createElement('div',{key:idx,style:(0,_main._l)(_main.styles.floatBlock),__source:{fileName:_jsxFileName,lineNumber:823}},
_react2.default.createElement(widget.Text,{__source:{fileName:_jsxFileName,lineNumber:824}},item.message),
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.hflex),__source:{fileName:_jsxFileName,lineNumber:825}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.spacer),__source:{fileName:_jsxFileName,lineNumber:826}}),
btns)));



}
return(
_react2.default.createElement('div',{key:idx,style:(0,_main._l)(_main.styles.floatBlock),onClick:function onClick(){
_this23.hideFloat(item);
},__source:{fileName:_jsxFileName,lineNumber:833}},
_react2.default.createElement(widget.Text,{__source:{fileName:_jsxFileName,lineNumber:836}},item.message)));


});
var time=null;
if(this.state.time){
time=
_react2.default.createElement(widget.Text,{style:[_main.styles.oneLine,_main.styles.flex0,_main.styles.textSmall],__source:{fileName:_jsxFileName,lineNumber:843}},
this.state.time.toLocaleTimeString(),':');


}
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.hbar,_main.styles.statusbar),__source:{fileName:_jsxFileName,lineNumber:849}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.floatBR),__source:{fileName:_jsxFileName,lineNumber:850}},
floats),

_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,spin?null:_main.styles.hidden),__source:{fileName:_jsxFileName,lineNumber:853}},
_react2.default.createElement('i',{className:spinCls,__source:{fileName:_jsxFileName,lineNumber:854}})),

time,
_react2.default.createElement(widget.Text,{
style:[_main.styles.oneLine,_main.styles.flex1,_main.styles.textSmall],__source:{fileName:_jsxFileName,lineNumber:857}},

this.state.message)));



}}]);return StatusbarCmp;}(_react2.default.Component);var


CalendarCmp=exports.CalendarCmp=function(_React$Component8){_inherits(CalendarCmp,_React$Component8);function CalendarCmp(){_classCallCheck(this,CalendarCmp);return _possibleConstructorReturn(this,(CalendarCmp.__proto__||Object.getPrototypeOf(CalendarCmp)).apply(this,arguments));}_createClass(CalendarCmp,[{key:'render',value:function render()

{var
date=this.props.date;
var title=date.toLocaleDateString(undefined,{
year:'2-digit',
month:'short'});

return(
_react2.default.createElement(common.CalendarPane,_extends({},
this.props,{
title:title,__source:{fileName:_jsxFileName,lineNumber:876}})));


}}]);return CalendarCmp;}(_react2.default.Component);