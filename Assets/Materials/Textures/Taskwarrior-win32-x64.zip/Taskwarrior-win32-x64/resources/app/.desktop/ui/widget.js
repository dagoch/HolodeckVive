'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.CalendarItem=exports.TaskPageInput=exports.CmdPageInput=exports.DnD=exports.Text=exports.IconMenu=exports.IconBtn=exports.Div=exports.LoadingIndicator=exports.eventInfo=undefined;var _slicedToArray=function(){function sliceIterator(arr,i){var _arr=[];var _n=true;var _d=false;var _e=undefined;try{for(var _i=arr[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_s;!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break;}}catch(err){_d=true;_e=err;}finally{try{if(!_n&&_i["return"])_i["return"]();}finally{if(_d)throw _e;}}return _arr;}return function(arr,i){if(Array.isArray(arr)){return arr;}else if((typeof Symbol==='function'?Symbol.iterator:'@@iterator')in Object(arr)){return sliceIterator(arr,i);}else{throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _jsxFileName='C:\\Users\\Michael\\src\\task\\app\\ui\\widget.desktop.js';var _react=require('react');var _react2=_interopRequireDefault(_react);
var _main=require('../styles/main');function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}

var eventInfo=exports.eventInfo=function eventInfo(e){
if(!e)return undefined;
return{
shift:e.shiftKey||false,
ctrl:e.ctrlKey||false,
alt:e.altKey||false,
meta:e.metaKey||false,
key:e.charCode||e.keyCode,
stop:function stop(){
e.stopPropagation();
}};

};

var LoadingIndicator=exports.LoadingIndicator=function LoadingIndicator(props){
return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.loadingIndicator),__source:{fileName:_jsxFileName,lineNumber:20}},
_react2.default.createElement('i',{className:'fa fa-circle-o-notch fa-spin fa-fw',__source:{fileName:_jsxFileName,lineNumber:21}})));


};

var Div=exports.Div=function Div(props){
return _react2.default.createElement('div',_extends({},props,{__source:{fileName:_jsxFileName,lineNumber:27}}),props.children);
};

var IconBtn=exports.IconBtn=function IconBtn(props){
return(
_react2.default.createElement('button',{
style:(0,_main._l)([_main.styles.btn]),
onClick:function onClick(evt){
if(props.onClick)props.onClick(eventInfo(evt));
},
title:props.title,__source:{fileName:_jsxFileName,lineNumber:32}},

_react2.default.createElement('i',{className:'fa fa-fw fa-'+props.icon,__source:{fileName:_jsxFileName,lineNumber:39}})));


};var

IconMenu=exports.IconMenu=function(_React$Component){_inherits(IconMenu,_React$Component);

function IconMenu(props){_classCallCheck(this,IconMenu);var _this=_possibleConstructorReturn(this,(IconMenu.__proto__||Object.getPrototypeOf(IconMenu)).call(this,
props));
_this.state={expanded:false};return _this;
}_createClass(IconMenu,[{key:'render',value:function render()

{var _props=
this.props,children=_props.children,dir=_props.dir,style=_props.style;var
expanded=this.state.expanded;
var menu=null;
var st=[_main.styles.hflex,_main.styles.menu];
var wst=[_main.styles.hflex,_main.styles.menu_popup];
if(style&&style.length){
st=st.concat(style);
wst=wst.concat(style);
};
if(expanded){
menu=
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.menu_wrap),__source:{fileName:_jsxFileName,lineNumber:63}},
_react2.default.createElement('div',{
onMouseLeave:this.onMenuHide.bind(this),
onClick:this.onMenuHide.bind(this),
style:(0,_main._l)(wst),__source:{fileName:_jsxFileName,lineNumber:64}},

children));



};
return(
_react2.default.createElement('div',{style:(0,_main._l)(st),__source:{fileName:_jsxFileName,lineNumber:75}},
menu,
_react2.default.createElement(IconBtn,{
icon:expanded?'caret-right':'caret-left',
onClick:this.onMenu.bind(this),__source:{fileName:_jsxFileName,lineNumber:77}})));



}},{key:'onMenu',value:function onMenu()

{
this.setState({
expanded:!this.state.expanded});

}},{key:'onMenuHide',value:function onMenuHide()

{
this.setState({
expanded:false});

}}]);return IconMenu;}(_react2.default.Component);


var Text=exports.Text=function Text(props){
var _st=[_main.styles.flex0,_main.styles.text];
if(props.style&&props.style.length){
_st=_st.concat(props.style);
}
var val=props.children||'';
var sfx='';
while(props.width>val.length+sfx.length){
sfx+=' ';
}
var editIcn=null;
if(props.editable===true){
editIcn=
_react2.default.createElement('i',{
className:'fa fa-fw fa-pencil text-edit',
style:_main.styles.text_edit,
onClick:function onClick(evt){
props.onEdit&&props.onEdit(eventInfo(evt));
},__source:{fileName:_jsxFileName,lineNumber:111}});



}else if(props.editable===false){
editIcn=
_react2.default.createElement('i',{className:'fa fa-fw',style:_main.styles.text_edit,__source:{fileName:_jsxFileName,lineNumber:122}});

}
var onDrag=undefined;
var draggable=false;
if(props.onDrag){
onDrag=function onDrag(e){var _props$onDrag=
props.onDrag(eventInfo(e)),_props$onDrag2=_slicedToArray(_props$onDrag,3),type=_props$onDrag2[0],value=_props$onDrag2[1],text=_props$onDrag2[2];
if(type&&value){
e.dataTransfer.setData('text/plain',text||value);
e.dataTransfer.setData(type,value);
};
};
draggable=true;
};
return(
_react2.default.createElement('div',{style:(0,_main._l)(_st),title:props.title||val,className:'text-wrap',onClick:function onClick(evt){
if(props.onClick)props.onClick(eventInfo(evt));
},__source:{fileName:_jsxFileName,lineNumber:138}},
_react2.default.createElement('span',{
className:'text',
draggable:draggable,
onDragStart:onDrag,__source:{fileName:_jsxFileName,lineNumber:141}},

val),

editIcn,
_react2.default.createElement('span',{__source:{fileName:_jsxFileName,lineNumber:149}},sfx)));


};var

DnD=exports.DnD=function(_React$Component2){_inherits(DnD,_React$Component2);

function DnD(props){_classCallCheck(this,DnD);var _this2=_possibleConstructorReturn(this,(DnD.__proto__||Object.getPrototypeOf(DnD)).call(this,
props));
_this2.dropCount=0;
_this2.dropTypes=[];
_this2.onDragStart=_this2.onDragStart.bind(_this2);
_this2.onDragFinish=_this2.onDragFinish.bind(_this2);
_this2.onDragOver=_this2.onDragOver.bind(_this2);
_this2.onDrop=_this2.onDrop.bind(_this2);return _this2;
}_createClass(DnD,[{key:'hasData',value:function hasData(

e){var _iteratorNormalCompletion=true;var _didIteratorError=false;var _iteratorError=undefined;try{
for(var _iterator=e.dataTransfer.types[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step;!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=true){var type=_step.value;
if(this.dropTypes.includes(type)){
return type;
};
}}catch(err){_didIteratorError=true;_iteratorError=err;}finally{try{if(!_iteratorNormalCompletion&&_iterator.return){_iterator.return();}}finally{if(_didIteratorError){throw _iteratorError;}}}
return undefined;
}},{key:'onDragStart',value:function onDragStart(

e){
if(!this.hasData(e))return;
this.dropCount+=1;
if(this.dropCount==1){
this.setState({
dragTarget:true});

};
e.preventDefault();
}},{key:'onDragOver',value:function onDragOver(

e){
if(!this.hasData(e))return;
e.preventDefault();
}},{key:'onDragFinish',value:function onDragFinish(

e){
if(!this.hasData(e))return;
this.dropCount-=1;
if(this.dropCount==0){
this.setState({
dragTarget:false});

};
e.preventDefault();
}},{key:'onDrop',value:function onDrop(

e){
var type=this.hasData(e);
if(!type)return;
this.dropCount=0;
this.setState({
dragTarget:false});

this.onDropHandler(type,e.dataTransfer.getData(type),eventInfo(e));
e.preventDefault();
}},{key:'onDropHandler',value:function onDropHandler(

type,data){
}}]);return DnD;}(_react2.default.Component);var



CmdPageInput=exports.CmdPageInput=function(_React$Component3){_inherits(CmdPageInput,_React$Component3);

function CmdPageInput(props){_classCallCheck(this,CmdPageInput);var _this3=_possibleConstructorReturn(this,(CmdPageInput.__proto__||Object.getPrototypeOf(CmdPageInput)).call(this,
props));
_this3.state={
cmd:props.cmd||''};return _this3;

}_createClass(CmdPageInput,[{key:'onChange',value:function onChange(

evt){
this.setState({
cmd:evt.target.value});

}},{key:'componentDidMount',value:function componentDidMount()

{
this.refs.input.focus();
}},{key:'render',value:function render()

{var _props2=
this.props,onRefresh=_props2.onRefresh,onPin=_props2.onPin,onClose=_props2.onClose;
var line1=
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.wflex),__source:{fileName:_jsxFileName,lineNumber:240}},
_react2.default.createElement('input',{
style:(0,_main._l)(_main.styles.inp,_main.styles.flex1),
type:'text',
ref:'input',
value:this.state.cmd,
onChange:this.onChange.bind(this),
onKeyPress:this.onKey.bind(this),
placeholder:'Command',__source:{fileName:_jsxFileName,lineNumber:241}}),

_react2.default.createElement(IconBtn,{icon:'refresh',onClick:onRefresh,__source:{fileName:_jsxFileName,lineNumber:250}}),
_react2.default.createElement(IconBtn,{
icon:'thumb-tack',
onClick:onPin,
title:'Pin/unpin panel',__source:{fileName:_jsxFileName,lineNumber:251}}),

_react2.default.createElement(IconBtn,{icon:'close',onClick:onClose,__source:{fileName:_jsxFileName,lineNumber:256}}));


return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0),__source:{fileName:_jsxFileName,lineNumber:260}},
line1));


}},{key:'input',value:function input()

{
return this.state;
}},{key:'filter',value:function filter()

{

}},{key:'onKey',value:function onKey(

evt){
if(evt.charCode==13){

this.props.onRefresh();
}
}}]);return CmdPageInput;}(_react2.default.Component);var




TaskPageInput=function(_React$Component4){_inherits(TaskPageInput,_React$Component4);

function TaskPageInput(props){_classCallCheck(this,TaskPageInput);var _this4=_possibleConstructorReturn(this,(TaskPageInput.__proto__||Object.getPrototypeOf(TaskPageInput)).call(this,
props));
_this4.state={
report:props.report||'',
filter:props.filter||''};

_this4.onSearch=_this4.onSearch.bind(_this4);return _this4;
}_createClass(TaskPageInput,[{key:'onReportChange',value:function onReportChange(

evt){
this.setState({
report:evt.target.value});

}},{key:'onFilterChange',value:function onFilterChange(

evt){
this.setState({
filter:evt.target.value});

}},{key:'componentDidMount',value:function componentDidMount()

{
this.refs.filter.addEventListener('search',this.onSearch);
}},{key:'componentWillUnmount',value:function componentWillUnmount()

{
this.refs.filter.removeEventListener('search',this.onSearch);
}},{key:'render',value:function render()

{var _props3=




this.props,onPin=_props3.onPin,onAdd=_props3.onAdd,onToggleSort=_props3.onToggleSort,sortMode=_props3.sortMode,expanded=_props3.expanded,onToggleExpand=_props3.onToggleExpand;
var line1=
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.wflex),__source:{fileName:_jsxFileName,lineNumber:322}},
_react2.default.createElement('input',{
style:(0,_main._l)(_main.styles.inp,_main.styles.flex1),
type:'text',
value:this.state.report,
onChange:this.onReportChange.bind(this),
onKeyPress:this.onKey.bind(this),
placeholder:'Report',__source:{fileName:_jsxFileName,lineNumber:323}}),

_react2.default.createElement(IconBtn,{
icon:'plus',
onClick:function onClick(e){
onAdd(e.meta);
},
title:'Add new',__source:{fileName:_jsxFileName,lineNumber:331}}),

_react2.default.createElement(IconBtn,{icon:'refresh',onClick:this.props.onRefresh,__source:{fileName:_jsxFileName,lineNumber:338}}),
_react2.default.createElement(IconBtn,{
icon:'thumb-tack',
onClick:onPin,
title:'Pin/unpin panel',__source:{fileName:_jsxFileName,lineNumber:339}}),

_react2.default.createElement(IconBtn,{icon:'close',onClick:this.props.onClose,__source:{fileName:_jsxFileName,lineNumber:344}}));


var sortIcon={
tree:'indent',
tree_back:'outdent',
list:'list-ul'}[
sortMode];
var expandIcon=expanded?'compress':'expand';
var line2=
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0,_main.styles.hflex,_main.styles.wflex),__source:{fileName:_jsxFileName,lineNumber:354}},
_react2.default.createElement('input',{
style:(0,_main._l)(_main.styles.inp,_main.styles.flex1),
type:'search',
ref:'filter',
value:this.state.filter,
onChange:this.onFilterChange.bind(this),
onKeyPress:this.onKey.bind(this),
placeholder:'Filter',__source:{fileName:_jsxFileName,lineNumber:355}}),

_react2.default.createElement(IconBtn,{icon:sortIcon,onClick:onToggleSort,__source:{fileName:_jsxFileName,lineNumber:364}}),
_react2.default.createElement(IconBtn,{icon:expandIcon,onClick:onToggleExpand,__source:{fileName:_jsxFileName,lineNumber:365}}));


return(
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.flex0),__source:{fileName:_jsxFileName,lineNumber:369}},
line1,
line2));


}},{key:'input',value:function input()

{
return this.state;
}},{key:'onSearch',value:function onSearch(

evt){
if(!this.state.filter){
this.props.onRefresh();
};
}},{key:'onKey',value:function onKey(

evt){
if(evt.charCode==13){

this.props.onRefresh();
}
}},{key:'filter',value:function filter(

_filter){
this.state.filter=_filter;
this.setState({
filter:_filter});

}}]);return TaskPageInput;}(_react2.default.Component);exports.TaskPageInput=TaskPageInput;var



CalendarItem=exports.CalendarItem=function(_DnD){_inherits(CalendarItem,_DnD);

function CalendarItem(props){_classCallCheck(this,CalendarItem);var _this5=_possibleConstructorReturn(this,(CalendarItem.__proto__||Object.getPrototypeOf(CalendarItem)).call(this,
props));
_this5.state={};return _this5;
}_createClass(CalendarItem,[{key:'render',value:function render()

{var _props4=
this.props,style=_props4.style,children=_props4.children,value=_props4.value,onClick=_props4.onClick,_onDrag=_props4.onDrag;
return(
_react2.default.createElement(Text,{
style:style,
onDrag:function onDrag(e){
return['tw/date',_onDrag(value,e.meta),_onDrag(value,e.meta)];
},
onDragEnter:this.onDragStart,
onDragLeave:this.onDragFinish,
onDragOver:this.onDragOver,
onClick:onClick,__source:{fileName:_jsxFileName,lineNumber:412}},

children));


}}]);return CalendarItem;}(DnD);