'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.AppPane=undefined;var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _jsxFileName='C:\\Users\\Michael\\src\\task\\app\\ui\\top.js';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();

var _react=require('react');var _react2=_interopRequireDefault(_react);
var _cmp=require('./cmp');var cmp=_interopRequireWildcard(_cmp);

var _ui=require('../tool/ui');function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}else{var newObj={};if(obj!=null){for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key))newObj[key]=obj[key];}}newObj.default=obj;return newObj;}}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var

AppPane=exports.AppPane=function(_React$Component){_inherits(AppPane,_React$Component);

function AppPane(props){_classCallCheck(this,AppPane);var _this=_possibleConstructorReturn(this,(AppPane.__proto__||Object.getPrototypeOf(AppPane)).call(this,
props));var
controller=props.controller;
_this.pageIndex=0;
_this.state={
pages:[],
defaultCmd:controller.defaultCmd,
layout:cmp.calculateLayout(),
panes:{
left:controller.panesConfig.left||controller.panesConfig._default,
right:controller.panesConfig.right||controller.panesConfig._default},

pins:[],
calendarDate:controller.fromCalendar()};return _this;

}_createClass(AppPane,[{key:'componentDidMount',value:function componentDidMount()

{var _this2=this;var
controller=this.props.controller;var _iteratorNormalCompletion=true;var _didIteratorError=false;var _iteratorError=undefined;try{
for(var _iterator=controller.panesConfig.pins[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step;!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=true){var pin=_step.value;
this.showPage({
type:'list',
report:pin.report,
filter:pin.filter},
true);
}}catch(err){_didIteratorError=true;_iteratorError=err;}finally{try{if(!_iteratorNormalCompletion&&_iterator.return){_iterator.return();}}finally{if(_didIteratorError){throw _iteratorError;}}}var _iteratorNormalCompletion2=true;var _didIteratorError2=false;var _iteratorError2=undefined;try{
for(var _iterator2=controller.panesConfig.pages[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step2;!(_iteratorNormalCompletion2=(_step2=_iterator2.next()).done);_iteratorNormalCompletion2=true){var page=_step2.value;
this.showPage({
type:'list',
report:page.report,
filter:page.filter});

}}catch(err){_didIteratorError2=true;_iteratorError2=err;}finally{try{if(!_iteratorNormalCompletion2&&_iterator2.return){_iterator2.return();}}finally{if(_didIteratorError2){throw _iteratorError2;}}}
controller.events.on('shortcut',function(code,config){
if(config.command=='sync'){
_this2.onSync();
};
if(config.command=='add'){
_this2.onAdd(undefined,'',false);
};
});
}},{key:'hidePane',value:function hidePane(

pane){var
panes=this.state.panes;
var state=panes[pane];
if(state!='float')return;
panes[pane]='hidden';
this.setState({
panes:panes});

}},{key:'togglePane',value:function togglePane(

pane){
var state=this.state.panes[pane];var
_modes=this.props.controller.panesConfig._modes;

if(!state)return;
if(state=='dock'){
state=_modes['hidden']?'hidden':'float';
}else if(state=='hidden'){
state=_modes["float"]?'float':'dock';
}else{
state=_modes['dock']?'dock':'hidden';
}
this.state.panes[pane]=state;
this.setState({
panes:this.state.panes});

}},{key:'checkActive',value:function checkActive(

key){
var page=this.current(key);
if(page&&(this.state.page==key||page.pin)){
return page;
};
return undefined;
}},{key:'onCommand',value:function onCommand()

{
this.showPage({
cmd:'',
type:'cmd'});

}},{key:'onAdd',value:function onAdd(

key,filter,completed){
var cmd=completed?'log':'add';
var input='';
if(filter)input=filter+' ';
this.refs.main.showInput(cmd,input,{
cmd:cmd});

}},{key:'onEdit',value:function onEdit(

key,cmd,tasks,input,unint,multiline){
if(unint){
return this.processInput(input,{
cmd:cmd,
tasks:tasks});

};
var title=cmd;
if(tasks.length){
title='{'+tasks.length+'} '+cmd;
};
var inp=input;
if(multiline&&inp){
inp=input.split(this.props.controller.multilineSep).join('\n');
};
this.refs.main.showInput(title,input,{
cmd:cmd,
input:inp,
tasks:tasks,
multiline:multiline});

}},{key:'processInput',value:function processInput(

input,ctx){var _this3=this;var cmd,denotateResult;return regeneratorRuntime.async(function processInput$(_context2){while(1){switch(_context2.prev=_context2.next){case 0:
cmd=ctx.cmd;if(!(
cmd=='reannotate')){_context2.next=9;break;}_context2.next=4;return regeneratorRuntime.awrap(
this.props.controller.cmd('denotate',ctx.input,ctx.tasks,true));case 4:denotateResult=_context2.sent;if(
denotateResult){_context2.next=7;break;}return _context2.abrupt('return',
false);case 7:
;
cmd='annotate';case 9:
;
if(ctx.multiline){
input=input.split('\n').join(this.props.controller.multilineSep);
};return _context2.abrupt('return',
(0,_ui.smooth)(function _callee(){return regeneratorRuntime.async(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:_context.next=2;return regeneratorRuntime.awrap(
_this3.props.controller.cmd(cmd,input,ctx.tasks));case 2:return _context.abrupt('return',_context.sent);case 3:case'end':return _context.stop();}}},null,_this3);}));case 13:case'end':return _context2.stop();}}},null,this);}},{key:'onClose',value:function onClose(



key){var _state=
this.state,pages=_state.pages,pins=_state.pins;
var idx=pins.findIndex(function(item){
return item.key==key;
});
if(idx!=-1){
pins.splice(idx,1);
this.setState({pins:pins});
return idx;
};
idx=pages.findIndex(function(item){
return item.key==key;
});
if(idx!=-1){
pages.splice(idx,1);
if(idx>0)idx--;
var page=pages[idx];
this.state.page=(page||{}).key;
this.setState({
pages:pages,
page:this.state.page});

if(page&&page.ref){
page.ref.refresh();
return idx;
};
};
return-1;
}},{key:'onRefreshed',value:function onRefreshed(

key,info){
var page=this.checkActive(key);
if(page&&!page.pin&&this.refs.navigation){
this.refs.navigation.hilite(info);
};
}},{key:'showPage',value:function showPage(

page,pin){var _state2=
this.state,pages=_state2.pages,pins=_state2.pins,layout=_state2.layout;var
controller=this.props.controller;
var item=pages.find(function(item){
return item.type==page.type&&item.ref&&item.ref.same(page);
});
if(!item||pin){
var paneCmp=null;
var key=Date.now()+ ++this.pageIndex;
var props={
id:key,
key:key,
ref:function ref(_ref){
_item.ref=_ref;
},
controller:this.props.controller,
onClose:this.onClose.bind(this),
checkActive:this.checkActive.bind(this),
onRefreshed:this.onRefreshed.bind(this),
onPin:this.togglePin.bind(this)};

if(page.type=='list'){
paneCmp=
_react2.default.createElement(TasksPagePane,_extends({},
props,{
expanded:controller.panesConfig.expanded,
report:page.report,
filter:page.filter,
layout:layout,
onAdd:this.onAdd.bind(this),
onEdit:this.onEdit.bind(this),
onSync:this.onSync.bind(this),__source:{fileName:_jsxFileName,lineNumber:205}}));


};
if(page.type=='cmd'){
paneCmp=
_react2.default.createElement(CmdPagePane,_extends({},
props,{
layout:layout,
cmd:page.cmd,__source:{fileName:_jsxFileName,lineNumber:219}}));


}
if(!paneCmp){
console.log('Invalid');
return;
};
var _item={
key:key,
type:page.type,
pin:pin||false,
cmp:paneCmp};

if(pin){
pins.push(_item);
key=this.state.page;
}else{
pages.push(_item);
};
this.setState({
pages:pages,
pins:pins,
page:key});

}else{
this.setState({
page:item.key});

}
}},{key:'togglePin',value:function togglePin(

key){
var page=this.current(key);var _state3=
this.state,pages=_state3.pages,pins=_state3.pins;
if(!page)return;
page.pin=!page.pin;

if(page.pin){
this.onClose(key);
pins.push(page);
}else{
pages.push(page);
var idx=pins.findIndex(function(item){
return item.key==key;
});
if(idx!=-1){
pins.splice(idx,1);
};
this.setState({
pages:pages,
page:key});

}
this.setState({pages:pages,pins:pins});
}},{key:'onNavigation',value:function onNavigation(

dir,index){var _state4=
this.state,pages=_state4.pages,page=_state4.page;
var idx=pages.findIndex(function(item){
return item.key==page;
});
switch(dir){
case-1:
if(idx>0)idx-=1;
break;
case 1:
if(idx<pages.length-1)idx+=1;
break;
case 0:
idx=index;}

this.setState({
page:pages[idx].key});

pages[idx].ref.refresh();
}},{key:'onContextClick',value:function onContextClick(

context){return regeneratorRuntime.async(function onContextClick$(_context3){while(1){switch(_context3.prev=_context3.next){case 0:_context3.next=2;return regeneratorRuntime.awrap(
this.props.controller.setContext(context));case 2:
this.refs.reports.refreshContexts();
this.hidePane('right');case 4:case'end':return _context3.stop();}}},null,this);}},{key:'onReportClick',value:function onReportClick(


report){var filter=arguments.length>1&&arguments[1]!==undefined?arguments[1]:'';
if(report.special){
var cmd=report.name;
if(filter){
cmd+=' '+filter;
};
this.showPage({
cmd:cmd,
type:'cmd'});

}else{
this.showPage({
report:report.name,
filter:filter,
type:'list'});

}
this.hidePane('right');
}},{key:'current',value:function current()

{var key=arguments.length>0&&arguments[0]!==undefined?arguments[0]:this.state.page;
var page=this.state.pages.find(function(item){
return item.key==key;
});
if(page)return page;
return this.state.pins.find(function(item){
return item.key==key;
});
}},{key:'openReport',value:function openReport(

type,filter){var name;return regeneratorRuntime.async(function openReport$(_context4){while(1){switch(_context4.prev=_context4.next){case 0:_context4.next=2;return regeneratorRuntime.awrap(
this.props.controller.specialList(type));case 2:name=_context4.sent;
if(name){
this.showPage({
report:name,
filter:filter,
type:'list'});

};case 5:case'end':return _context4.stop();}}},null,this);}},{key:'onTagClick',value:function onTagClick(


tag,special){
this.hidePane('left');
if(special){
return this.openReport('tag','+'+tag.name);
};
var page=this.current();
if(page&&page.ref){
page.ref.filter('+'+tag.name);
}
}},{key:'onUdaClick',value:function onUdaClick(

value,special){
this.hidePane('left');
var page=this.current();
if(page&&page.ref){
page.ref.filter(value);
}
}},{key:'onProjectClick',value:function onProjectClick(

project,special){
this.hidePane('left');
if(special){
return this.openReport('project','pro:'+project.project);
};
var page=this.current();
if(page&&page.ref){
page.ref.filter('pro:'+project.project);
}
}},{key:'onTagEdit',value:function onTagEdit(

tag){
var title='+'+tag.name+' modify';
this.refs.main.showInput(title,'-'+tag.name+' +'+tag.name,{
cmd:title});

}},{key:'onProjectEdit',value:function onProjectEdit(

project){
var title='pro:'+project.project+' modify';
this.refs.main.showInput(title,'pro:'+project.project,{
cmd:title});

}},{key:'onUndo',value:function onUndo(){return regeneratorRuntime.async(function onUndo$(_context5){while(1){switch(_context5.prev=_context5.next){case 0:_context5.next=2;return regeneratorRuntime.awrap(


this.props.controller.undo());case 2:return _context5.abrupt('return',_context5.sent);case 3:case'end':return _context5.stop();}}},null,this);}},{key:'onSync',value:function onSync(){var success;return regeneratorRuntime.async(function onSync$(_context6){while(1){switch(_context6.prev=_context6.next){case 0:_context6.next=2;return regeneratorRuntime.awrap(



this.props.controller.sync());case 2:success=_context6.sent;
if(success){
this.props.controller.info('Sync complete');
}case 4:case'end':return _context6.stop();}}},null,this);}},{key:'onEditConfig',value:function onEditConfig(){var controller;return regeneratorRuntime.async(function onEditConfig$(_context7){while(1){switch(_context7.prev=_context7.next){case 0:



controller=this.props.controller;_context7.next=3;return regeneratorRuntime.awrap(
controller.editConfig());case 3:case'end':return _context7.stop();}}},null,this);}},{key:'onMakeBackup',value:function onMakeBackup(){var controller;return regeneratorRuntime.async(function onMakeBackup$(_context8){while(1){switch(_context8.prev=_context8.next){case 0:



controller=this.props.controller;_context8.next=3;return regeneratorRuntime.awrap(
controller.makeBackup());case 3:case'end':return _context8.stop();}}},null,this);}},{key:'onManageProfiles',value:function onManageProfiles()


{var
controller=this.props.controller;
this.refs.main.showProfiles(controller.provider);
}},{key:'onCalendarChange',value:function onCalendarChange(

dir,special){
var date=this.state.calendarDate;
if(dir===0){
date=new Date();
date.setDate(1);
}else{
if(special){
date.setFullYear(date.getFullYear()+dir);
}else{
date.setMonth(date.getMonth()+dir);
};
}
this.setState({calendarDate:date});
}},{key:'onCalendarClick',value:function onCalendarClick(

date,special){var

calendarConfig=this.props.controller.calendarConfig;
var cmd=special?calendarConfig.filterAlt:calendarConfig.filter;
var filter=cmd+':'+date;
var page=this.current();
if(page&&page.ref){
page.ref.filter(filter);
}
this.hidePane(calendarConfig.pane);
}},{key:'onCalendarDrag',value:function onCalendarDrag(

date,special){var
calendarConfig=this.props.controller.calendarConfig;
var cmd=special?calendarConfig.commandAlt:calendarConfig.command;
return cmd+':'+date;
}},{key:'onLayoutChange',value:function onLayoutChange(

l){var
layout=this.state.layout;
var fields=['orientation','width','height','wide','tall'];var _iteratorNormalCompletion3=true;var _didIteratorError3=false;var _iteratorError3=undefined;try{
for(var _iterator3=fields[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step3;!(_iteratorNormalCompletion3=(_step3=_iterator3.next()).done);_iteratorNormalCompletion3=true){var f=_step3.value;
if(l[f]!==layout[f]){
this.setState({layout:l});
return true;
};
}}catch(err){_didIteratorError3=true;_iteratorError3=err;}finally{try{if(!_iteratorNormalCompletion3&&_iterator3.return){_iterator3.return();}}finally{if(_didIteratorError3){throw _iteratorError3;}}};
return false;
}},{key:'onExternalUri',value:function onExternalUri(

uri){
var parts=/([a-z\+]+):\/\/([a-f0-9\-]+)\/(.+)/.exec(uri);
if(!parts){
return false;
};
var info={
scheme:parts[1],
type:parts[1].substr(3),
id:parts[2],
path:parts[3],
parts:parts[3].split('/').map(function(part){return decodeURIComponent(part);})};

console.log('URL:',info);
if(info.type=='tasks'){
this.showPage({
report:info.parts[0],
filter:info.parts[1]||'',
type:'list',
silent:true});

};
}},{key:'render',value:function render()

{
if(!this.state)return(
_react2.default.createElement(cmp.AppCmp,{__source:{fileName:_jsxFileName,lineNumber:487}}));var _state5=

this.state,panes=_state5.panes,pages=_state5.pages,pins=_state5.pins,page=_state5.page,calendarDate=_state5.calendarDate,layout=_state5.layout;var
controller=this.props.controller;
var leftExtra=[];
var rightExtra=[];
if(['left','right'].includes(controller.calendarConfig.pane)){
var cal=
_react2.default.createElement(cmp.CalendarCmp,{
onChange:this.onCalendarChange.bind(this),
onClick:this.onCalendarClick.bind(this),
onDrag:this.onCalendarDrag.bind(this),
date:calendarDate,
data:controller.calendar(calendarDate),
layout:layout,__source:{fileName:_jsxFileName,lineNumber:495}});


if('left'==controller.calendarConfig.pane){
leftExtra.push(cal);
}
if('right'==controller.calendarConfig.pane){
rightExtra.push(cal);
}
}
return(
_react2.default.createElement(cmp.AppCmp,{
onExternalUri:this.onExternalUri.bind(this),
onLayoutChange:this.onLayoutChange.bind(this),__source:{fileName:_jsxFileName,lineNumber:512}},

_react2.default.createElement(ToolbarPane,{
onCommand:this.onCommand.bind(this),
onTogglePane:this.togglePane.bind(this),
onUndo:this.onUndo.bind(this),
info:controller.providerInfo(),
onSync:this.onSync.bind(this),
onEditConfig:this.onEditConfig.bind(this),
onManageProfiles:this.onManageProfiles.bind(this),
onMakeBackup:this.onMakeBackup.bind(this),__source:{fileName:_jsxFileName,lineNumber:516}}),

_react2.default.createElement(CenterPane,{__source:{fileName:_jsxFileName,lineNumber:526}},
_react2.default.createElement(MainPane,{
controller:controller,
navigation:panes.navigation,
panes:panes,
pages:pages,
pins:pins,
page:page,
layout:layout,
ref:'main',
onNavigation:this.onNavigation.bind(this),
onInput:this.processInput.bind(this),__source:{fileName:_jsxFileName,lineNumber:527}}),

_react2.default.createElement(NavigationPane,{
controller:controller,
onTagClick:this.onTagClick.bind(this),
onUdaClick:this.onUdaClick.bind(this),
onProjectClick:this.onProjectClick.bind(this),
onTagEdit:this.onTagEdit.bind(this),
onProjectEdit:this.onProjectEdit.bind(this),
ref:'navigation',
mode:panes.left,
tagsMode:this.paneMode('tags'),
projectsMode:this.paneMode('reports'),
onHide:this.hidePane.bind(this),
extra:leftExtra,
layout:layout,__source:{fileName:_jsxFileName,lineNumber:539}}),

_react2.default.createElement(ReportsPane,{
ref:'reports',
controller:controller,
reportsExpandable:controller.reportsSublist?true:false,
onReportClick:this.onReportClick.bind(this),
onContextClick:this.onContextClick.bind(this),
mode:panes.right,
contextsMode:this.paneMode('contexts'),
reportsMode:this.paneMode('reports'),
onHide:this.hidePane.bind(this),
extra:rightExtra,
layout:layout,__source:{fileName:_jsxFileName,lineNumber:554}})),


_react2.default.createElement(StatusbarPane,{
controller:controller,__source:{fileName:_jsxFileName,lineNumber:568}})));



}},{key:'paneMode',value:function paneMode(

name){
return this.props.controller.panesConfig[name];
}}]);return AppPane;}(_react2.default.Component);var


ToolbarPane=function(_React$Component2){_inherits(ToolbarPane,_React$Component2);function ToolbarPane(){_classCallCheck(this,ToolbarPane);return _possibleConstructorReturn(this,(ToolbarPane.__proto__||Object.getPrototypeOf(ToolbarPane)).apply(this,arguments));}_createClass(ToolbarPane,[{key:'render',value:function render()

{
return _react2.default.createElement(cmp.ToolbarCmp,_extends({},this.props,{__source:{fileName:_jsxFileName,lineNumber:583}}));
}}]);return ToolbarPane;}(_react2.default.Component);var


StatusbarPane=function(_React$Component3){_inherits(StatusbarPane,_React$Component3);

function StatusbarPane(props){_classCallCheck(this,StatusbarPane);var _this5=_possibleConstructorReturn(this,(StatusbarPane.__proto__||Object.getPrototypeOf(StatusbarPane)).call(this,
props));
_this5.state={};return _this5;
}_createClass(StatusbarPane,[{key:'componentDidMount',value:function componentDidMount()

{var _this6=this;
this.props.controller.events.on('notify:error',function(err){
_this6.refs.cmp.showMessage('error',err);
});
this.props.controller.events.on('notify:info',function(msg){
_this6.refs.cmp.showMessage('info',msg);
});
this.props.controller.events.on('question',function(msg,choices,resp){
_this6.refs.cmp.showMessage('question',msg,choices,resp);
});
this.props.controller.events.on('sync:start',function(){
_this6.setState({
spin:true});

});
this.props.controller.events.on('sync:finish',function(){
_this6.setState({
spin:false});

});
}},{key:'render',value:function render()

{var
controller=this.props.controller;
return(
_react2.default.createElement(cmp.StatusbarCmp,_extends({
ref:'cmp'},
this.props,{
foreground:controller.foreground,
spin:this.state.spin,__source:{fileName:_jsxFileName,lineNumber:619}})));


}}]);return StatusbarPane;}(_react2.default.Component);var




PagePane=function(_React$Component4){_inherits(PagePane,_React$Component4);

function PagePane(props){_classCallCheck(this,PagePane);var _this7=_possibleConstructorReturn(this,(PagePane.__proto__||Object.getPrototypeOf(PagePane)).call(this,
props));
_this7.refreshHandler=_this7.onChanged.bind(_this7);return _this7;
}_createClass(PagePane,[{key:'setLayout',value:function setLayout(

layout){
this.setState({layout:layout});
}},{key:'onClose',value:function onClose()


{
this.props.onClose(this.props.id);
}},{key:'onPin',value:function onPin()

{
this.props.onPin(this.props.id);
}},{key:'onChanged',value:function onChanged()

{
if(this.props.checkActive(this.props.id)){
this.refresh();
};
}},{key:'componentDidMount',value:function componentDidMount()

{
this.props.controller.events.on('change',this.refreshHandler);
this.refresh();
}},{key:'componentWillUnmount',value:function componentWillUnmount()

{
this.props.controller.events.removeListener('change',this.refreshHandler);
}}]);return PagePane;}(_react2.default.Component);var



CmdPagePane=function(_PagePane){_inherits(CmdPagePane,_PagePane);

function CmdPagePane(props){_classCallCheck(this,CmdPagePane);var _this8=_possibleConstructorReturn(this,(CmdPagePane.__proto__||Object.getPrototypeOf(CmdPagePane)).call(this,
props));
_this8.state={};return _this8;
}_createClass(CmdPagePane,[{key:'componentDidMount',value:function componentDidMount()

{
if(this.props.cmd){
this.run();
}
}},{key:'input',value:function input()

{
return this.refs.cmp.input();
}},{key:'same',value:function same(

page){
var data=this.input();
return page.cmd===data.cmd;
}},{key:'filter',value:function filter(

_filter){

this.run();
}},{key:'render',value:function render()

{
return(
_react2.default.createElement(cmp.CmdPageCmp,_extends({},
this.props,{
ref:'cmp',
info:this.state.info,
loading:this.state.loading,
onRefresh:this.run.bind(this),
onClose:this.onClose.bind(this),
onPin:this.onPin.bind(this),__source:{fileName:_jsxFileName,lineNumber:697}})));


}},{key:'refresh',value:function refresh()

{
}},{key:'run',value:function run()

{var _this9=this;var _props=
this.props,controller=_props.controller,onRefreshed=_props.onRefreshed,id=_props.id;
var data=this.input();
this.setState({loading:true});
(0,_ui.smooth)(function _callee2(){var info;return regeneratorRuntime.async(function _callee2$(_context9){while(1){switch(_context9.prev=_context9.next){case 0:_context9.next=2;return regeneratorRuntime.awrap(
controller.cmdRaw(data.cmd,function(outp){
_this9.setState({
info:outp});

}));case 2:info=_context9.sent;
if(info){

_this9.setState({
info:info});

onRefreshed(id,info);
}
_this9.setState({loading:false});case 5:case'end':return _context9.stop();}}},null,_this9);});

}}]);return CmdPagePane;}(PagePane);var


TasksPagePane=function(_PagePane2){_inherits(TasksPagePane,_PagePane2);

function TasksPagePane(props){_classCallCheck(this,TasksPagePane);var _this10=_possibleConstructorReturn(this,(TasksPagePane.__proto__||Object.getPrototypeOf(TasksPagePane)).call(this,
props));
_this10.state={
selection:{},
filter:props.filter,
layout:props.layout,
sortMode:'list',
expanded:props.expanded||false};return _this10;

}_createClass(TasksPagePane,[{key:'toggleSort',value:function toggleSort()

{var
sortMode=this.state.sortMode;
var modes=['list','tree','tree_back'];
this.setState({
sortMode:modes[(modes.indexOf(sortMode)+1)%modes.length]});

this.refresh();
}},{key:'toggleExpand',value:function toggleExpand()

{var
expanded=this.state.expanded;
this.setState({expanded:!expanded});
}},{key:'select',value:function select(

task){var
selection=this.state.selection;
if(selection[task.uuid]){

selection[task.uuid]=false;
}else{
selection[task.uuid]=true;
}
this.setState({selection:selection});
}},{key:'onAdd',value:function onAdd(

completed){
var cmd=[];
var input=this.input().filter;
if(input)cmd.push(input);for(var _len=arguments.length,cmds=Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){cmds[_key-1]=arguments[_key];}
cmds.forEach(function(item){
if(item)cmd.push(item);
});
this.props.onAdd(this.props.id,cmd.join(' '),completed);
}},{key:'onEdit',value:function onEdit(

task,cmd,input){var unint=arguments.length>3&&arguments[3]!==undefined?arguments[3]:false;var multiline=arguments.length>4&&arguments[4]!==undefined?arguments[4]:false;var _state6=
this.state,selection=_state6.selection,info=_state6.info;
var tasks=[];
if(info&&info.tasks){
tasks=info.tasks.filter(function(item){return selection[item.uuid];});
}
if(!tasks.length||tasks.indexOf(task)==-1){
if(task)tasks=[task];
}
this.props.onEdit(this.props.id,cmd,tasks,input,unint,multiline);
}},{key:'filter',value:function filter(

_filter2){
this.refs.cmp.filter(_filter2);
this.refresh(true);
}},{key:'input',value:function input()

{
return this.refs.cmp.input();
}},{key:'same',value:function same(

page){
var data=this.input();
return page.filter===data.filter&&page.report===data.report;
}},{key:'onDone',value:function onDone(

task){var uuid,status;return regeneratorRuntime.async(function onDone$(_context10){while(1){switch(_context10.prev=_context10.next){case 0:
uuid=task.uuid,status=task.status;if(!(
['waiting','pending'].indexOf(status)!=-1)){_context10.next=5;break;}return _context10.abrupt('return',
this.onEdit(task,'done','',true));case 5:return _context10.abrupt('return',

this.props.controller.err('Invalid task'));case 6:
;case 7:case'end':return _context10.stop();}}},null,this);}},{key:'render',value:function render()


{var _this11=this;
return(
_react2.default.createElement(cmp.TaskPageCmp,_extends({},
this.props,{
filter:this.state.filter,
layout:this.state.layout,
ref:'cmp',
info:this.state.info,
selection:this.state.selection,
loading:this.state.loading,
sortMode:this.state.sortMode,
expanded:this.state.expanded,
onToggleExpand:function onToggleExpand(){
_this11.toggleExpand();
},
onToggleSort:this.toggleSort.bind(this),
onRefresh:function onRefresh(){
_this11.refresh(true);
},
onDone:this.onDone.bind(this),
onClose:this.onClose.bind(this),
onAdd:this.onAdd.bind(this),
onEdit:this.onEdit.bind(this),
onPin:this.onPin.bind(this),
onSelect:this.select.bind(this),__source:{fileName:_jsxFileName,lineNumber:819}})));


}},{key:'refresh',value:function refresh(

reset){var _this12=this;
this.setState({loading:true});var _props2=
this.props,controller=_props2.controller,onRefreshed=_props2.onRefreshed,id=_props2.id;
var data=this.input();
(0,_ui.smooth)(function _callee3(){var oldInfo,info,newState;return regeneratorRuntime.async(function _callee3$(_context11){while(1){switch(_context11.prev=_context11.next){case 0:
oldInfo=reset?undefined:_this12.state.info;_context11.next=3;return regeneratorRuntime.awrap(
controller.filter(data.report,data.filter,oldInfo,_this12.state.sortMode));case 3:info=_context11.sent;
newState={
loading:false};

if(info){

if(reset){
newState.selection={};
}
newState.info=info;
onRefreshed(id,info);
}
_this12.setState(newState);case 7:case'end':return _context11.stop();}}},null,_this12);});

}}]);return TasksPagePane;}(PagePane);var




MainPane=function(_React$Component5){_inherits(MainPane,_React$Component5);function MainPane(){_classCallCheck(this,MainPane);return _possibleConstructorReturn(this,(MainPane.__proto__||Object.getPrototypeOf(MainPane)).apply(this,arguments));}_createClass(MainPane,[{key:'showInput',value:function showInput()

{for(var _len2=arguments.length,args=Array(_len2),_key2=0;_key2<_len2;_key2++){args[_key2]=arguments[_key2];}
return this.refs.cmp.showInput.apply(this.refs.cmp,args);
}},{key:'showProfiles',value:function showProfiles()

{for(var _len3=arguments.length,args=Array(_len3),_key3=0;_key3<_len3;_key3++){args[_key3]=arguments[_key3];}
return this.refs.cmp.showProfiles.apply(this.refs.cmp,args);
}},{key:'loadActive',value:function loadActive(){var controller;return regeneratorRuntime.async(function loadActive$(_context12){while(1){switch(_context12.prev=_context12.next){case 0:


controller=this.props.controller;_context12.next=3;return regeneratorRuntime.awrap(
controller.makePopupData());case 3:return _context12.abrupt('return',_context12.sent);case 4:case'end':return _context12.stop();}}},null,this);}},{key:'componentDidMount',value:function componentDidMount()


{var _this14=this;var
controller=this.props.controller;var
cmp=this.refs.cmp;
if(!cmp.showPopup||!controller.popupEnabled())return;
controller.events.on('change',function(){
(0,_ui.smooth)(function _callee4(){return regeneratorRuntime.async(function _callee4$(_context13){while(1){switch(_context13.prev=_context13.next){case 0:_context13.t0=
cmp;_context13.next=3;return regeneratorRuntime.awrap(_this14.loadActive());case 3:_context13.t1=_context13.sent;_context13.t0.updatePopup.call(_context13.t0,_context13.t1);case 5:case'end':return _context13.stop();}}},null,_this14);});

});
(0,_ui.smooth)(function _callee5(){return regeneratorRuntime.async(function _callee5$(_context14){while(1){switch(_context14.prev=_context14.next){case 0:_context14.t0=
cmp;_context14.t1=controller.cssConfig;_context14.next=4;return regeneratorRuntime.awrap(_this14.loadActive());case 4:_context14.t2=_context14.sent;_context14.t3=controller.panesConfig.popup;_context14.t0.showPopup.call(_context14.t0,_context14.t1,_context14.t2,_context14.t3);case 7:case'end':return _context14.stop();}}},null,_this14);});

}},{key:'render',value:function render()

{
return(
_react2.default.createElement(cmp.MainCmp,_extends({},
this.props,{
ref:'cmp',
onNavigation:this.props.onNavigation,__source:{fileName:_jsxFileName,lineNumber:902}})));


}}]);return MainPane;}(_react2.default.Component);var



NavigationPane=function(_React$Component6){_inherits(NavigationPane,_React$Component6);

function NavigationPane(props){_classCallCheck(this,NavigationPane);var _this15=_possibleConstructorReturn(this,(NavigationPane.__proto__||Object.getPrototypeOf(NavigationPane)).call(this,
props));
_this15.state={
tags:[],
projects:[],
tagsExpanded:false,
projectsExpanded:false};

_this15.mounted=false;return _this15;
}_createClass(NavigationPane,[{key:'componentDidMount',value:function componentDidMount()

{
this.props.controller.events.on('change',this.refresh.bind(this));
this.refresh();
this.mounted=true;
}},{key:'componentWillUnmount',value:function componentWillUnmount()

{
this.mounted=false;
}},{key:'refresh',value:function refresh()

{
this.refreshProjects();
this.refreshTags();
}},{key:'toggleExpand',value:function toggleExpand(

prop){
if(!this.mounted)return false;
var state={};
state[prop]=!this.state[prop];
this.setState(state);
}},{key:'refreshTags',value:function refreshTags(){var _this16=this;return regeneratorRuntime.async(function refreshTags$(_context16){while(1){switch(_context16.prev=_context16.next){case 0:return _context16.abrupt('return',


(0,_ui.smooth)(function _callee6(){var tags;return regeneratorRuntime.async(function _callee6$(_context15){while(1){switch(_context15.prev=_context15.next){case 0:_context15.next=2;return regeneratorRuntime.awrap(
_this16.props.controller.tags(_this16.state.tagsExpanded));case 2:tags=_context15.sent;
if(tags&&_this16.mounted)_this16.setState({tags:tags});case 4:case'end':return _context15.stop();}}},null,_this16);}));case 1:case'end':return _context16.stop();}}},null,this);}},{key:'refreshProjects',value:function refreshProjects(){var _this17=this;return regeneratorRuntime.async(function refreshProjects$(_context18){while(1){switch(_context18.prev=_context18.next){case 0:return _context18.abrupt('return',




(0,_ui.smooth)(function _callee7(){var projects;return regeneratorRuntime.async(function _callee7$(_context17){while(1){switch(_context17.prev=_context17.next){case 0:_context17.next=2;return regeneratorRuntime.awrap(
_this17.props.controller.projects(_this17.state.projectsExpanded));case 2:projects=_context17.sent;
if(projects&&_this17.mounted)_this17.setState({projects:projects});case 4:case'end':return _context17.stop();}}},null,_this17);}));case 1:case'end':return _context18.stop();}}},null,this);}},{key:'hilite',value:function hilite(



info){
if(!this.mounted)return false;
this.setState({
info:info});

return true;
}},{key:'render',value:function render()

{var _this18=this;var _props3=
this.props,controller=_props3.controller,onUdaClick=_props3.onUdaClick;
var udaPanels=controller.udaPanels().map(function(item){
return(
_react2.default.createElement(cmp.UdaPaneCmp,{
compact:true,
visible:true,
info:_this18.state.info,
config:item,
key:item.id,
title:item.label,
onClick:function onClick(value,meta){
onUdaClick(value,meta);
},__source:{fileName:_jsxFileName,lineNumber:973}}));


});
return(
_react2.default.createElement(cmp.NavigationCmp,_extends({},
this.props,{
tags:this.state.tags,
tagsExpanded:this.state.tagsExpanded,
projectsExpanded:this.state.projectsExpanded,
projects:this.state.projects,
info:this.state.info,
onRefreshProjects:this.refreshProjects.bind(this),
onRefreshTags:this.refreshTags.bind(this),
udaPanels:udaPanels,
onExpandProjects:function onExpandProjects(){
_this18.toggleExpand('projectsExpanded');
_this18.refreshProjects();
},
onExpandTags:function onExpandTags(){
_this18.toggleExpand('tagsExpanded');
_this18.refreshTags();
},__source:{fileName:_jsxFileName,lineNumber:987}})));


}}]);return NavigationPane;}(_react2.default.Component);var


ReportsPane=function(_React$Component7){_inherits(ReportsPane,_React$Component7);

function ReportsPane(props){_classCallCheck(this,ReportsPane);var _this19=_possibleConstructorReturn(this,(ReportsPane.__proto__||Object.getPrototypeOf(ReportsPane)).call(this,
props));
_this19.state={
reports:[],
reportsExpanded:props.reportsExpandable?false:undefined};return _this19;

}_createClass(ReportsPane,[{key:'componentDidMount',value:function componentDidMount()

{
this.refreshReports();
this.refreshContexts();
}},{key:'refreshReports',value:function refreshReports(){var _this20=this;return regeneratorRuntime.async(function refreshReports$(_context20){while(1){switch(_context20.prev=_context20.next){case 0:return _context20.abrupt('return',


(0,_ui.smooth)(function _callee8(){var reportsExpanded,reports;return regeneratorRuntime.async(function _callee8$(_context19){while(1){switch(_context19.prev=_context19.next){case 0:
reportsExpanded=_this20.state.reportsExpanded;_context19.next=3;return regeneratorRuntime.awrap(
_this20.props.controller.reports(reportsExpanded));case 3:reports=_context19.sent;
_this20.setState({
reports:reports});case 5:case'end':return _context19.stop();}}},null,_this20);}));case 1:case'end':return _context20.stop();}}},null,this);}},{key:'refreshContexts',value:function refreshContexts(){var _this21=this;return regeneratorRuntime.async(function refreshContexts$(_context22){while(1){switch(_context22.prev=_context22.next){case 0:return _context22.abrupt('return',





(0,_ui.smooth)(function _callee9(){var data;return regeneratorRuntime.async(function _callee9$(_context21){while(1){switch(_context21.prev=_context21.next){case 0:_context21.next=2;return regeneratorRuntime.awrap(
_this21.props.controller.contexts());case 2:data=_context21.sent;
_this21.setState({
contexts:data});case 4:case'end':return _context21.stop();}}},null,_this21);}));case 1:case'end':return _context22.stop();}}},null,this);}},{key:'toggleExpand',value:function toggleExpand(




prop){
var state={};
state[prop]=!this.state[prop];
this.setState(state);
}},{key:'render',value:function render()

{var _this22=this;
return(
_react2.default.createElement(cmp.ReportsCmp,_extends({},
this.props,{
reports:this.state.reports,
contexts:this.state.contexts,
onReportsRefresh:this.refreshReports.bind(this),
onContextsRefresh:this.refreshContexts.bind(this),
reportsExpanded:this.state.reportsExpanded,
onExpandReports:function onExpandReports(){
_this22.toggleExpand('reportsExpanded');
_this22.refreshReports();
},
ref:'cmp',__source:{fileName:_jsxFileName,lineNumber:1052}})));


}}]);return ReportsPane;}(_react2.default.Component);var


CenterPane=function(_React$Component8){_inherits(CenterPane,_React$Component8);function CenterPane(){_classCallCheck(this,CenterPane);return _possibleConstructorReturn(this,(CenterPane.__proto__||Object.getPrototypeOf(CenterPane)).apply(this,arguments));}_createClass(CenterPane,[{key:'render',value:function render()
{
return _react2.default.createElement(cmp.CenterCmp,{__source:{fileName:_jsxFileName,lineNumber:1071}},this.props.children);
}}]);return CenterPane;}(_react2.default.Component);