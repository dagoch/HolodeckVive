'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.start=undefined;var _jsxFileName='C:\\Users\\Michael\\src\\task\\app\\popup.desktop.js';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _react=require('react');var _react2=_interopRequireDefault(_react);
var _reactDom=require('react-dom');var _reactDom2=_interopRequireDefault(_reactDom);
require('babel-polyfill');

var _main=require('./styles/main');
var _style=require('./styles/style');function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var _require=

require('electron'),ipcRenderer=_require.ipcRenderer;var

DesktopMain=function(_React$Component){_inherits(DesktopMain,_React$Component);

function DesktopMain(props){_classCallCheck(this,DesktopMain);var _this=_possibleConstructorReturn(this,(DesktopMain.__proto__||Object.getPrototypeOf(DesktopMain)).call(this,
props));

ipcRenderer.on('init',function(evt,css,config){

(0,_style.init)(css);
(0,_main.init)(css);
});

ipcRenderer.on('data',function(evt,data){

_this.setState({data:data});
});
_this.state={};return _this;
}_createClass(DesktopMain,[{key:'mouseHandler',value:function mouseHandler(

evt){
ipcRenderer.send('popup-raise');
}},{key:'componentDidMount',value:function componentDidMount()

{
ipcRenderer.send('popup-opened');
}},{key:'render',value:function render()

{var _this2=this;var
data=this.state.data;
var st=[_main.styles.popup,_main.styles.color_completed_bg];
if(data&&data.active){
st.push(_main.styles.color_active_bg);
};
return(
_react2.default.createElement('div',{style:(0,_main._l)(st),onMouseDown:function onMouseDown(evt){
return _this2.mouseHandler(evt);
},__source:{fileName:_jsxFileName,lineNumber:43}},
_react2.default.createElement('div',{style:(0,_main._l)(_main.styles.popup_move),__source:{fileName:_jsxFileName,lineNumber:46}})));


}}]);return DesktopMain;}(_react2.default.Component);


var start=exports.start=function start(){
var domNode=document.getElementById('app');
_reactDom2.default.render(_react2.default.createElement(DesktopMain,{}),domNode);
};