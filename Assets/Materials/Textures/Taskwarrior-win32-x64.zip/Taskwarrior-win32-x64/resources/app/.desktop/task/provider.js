'use strict';Object.defineProperty(exports,"__esModule",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}var spawn=require('child_process').spawn;
var readline=require('readline');var _require=
require('electron'),ipcRenderer=_require.ipcRenderer;

var fs=require('fs');var

TaskProvider=exports.TaskProvider=function(){

function TaskProvider(config){_classCallCheck(this,TaskProvider);
this.config=config;
this.timerIDs={};
}_createClass(TaskProvider,[{key:'readConfig',value:function readConfig(

filename,key){return regeneratorRuntime.async(function readConfig$(_context){while(1){switch(_context.prev=_context.next){case 0:return _context.abrupt('return',
new Promise(function(rsp,rej){
var home=process.env.HOME;
if(home)home+='/';
fs.readFile(home+filename,{encoding:'utf8'},function(err,data){
if(err){
console.log('readConfig:',err);

return rsp(undefined);
};
var value=void 0;
data.split('\n').forEach(function(line){
var eq=line.indexOf('=');
if(eq>0&&line.substr(0,eq).trim()==key){
value=line.substr(eq+1).trim();
};
});
return rsp(value);
});
}));case 1:case'end':return _context.stop();}}},null,this);}},{key:'checkTask',value:function checkTask(){var code;return regeneratorRuntime.async(function checkTask$(_context2){while(1){switch(_context2.prev=_context2.next){case 0:_context2.prev=0;_context2.next=3;return regeneratorRuntime.awrap(




this.call(['--version']));case 3:code=_context2.sent;if(!(
code!=0)){_context2.next=7;break;}
console.log('Task is not good',code);return _context2.abrupt('return',
false);case 7:
;_context2.next=14;break;case 10:_context2.prev=10;_context2.t0=_context2['catch'](0);

console.log('Task is not available',_context2.t0);return _context2.abrupt('return',
false);case 14:
;return _context2.abrupt('return',
true);case 16:case'end':return _context2.stop();}}},null,this,[[0,10]]);}},{key:'findBinary',value:function findBinary(){var taskPath;return regeneratorRuntime.async(function findBinary$(_context3){while(1){switch(_context3.prev=_context3.next){case 0:_context3.next=2;return regeneratorRuntime.awrap(



this.checkTask());case 2:if(!_context3.sent){_context3.next=4;break;}return _context3.abrupt('return',
true);case 4:if(!(

process.platform=='darwin')){_context3.next=10;break;}
this.config.task='/usr/local/bin/task';_context3.next=8;return regeneratorRuntime.awrap(
this.checkTask());case 8:if(!_context3.sent){_context3.next=10;break;}return _context3.abrupt('return',
true);case 10:

;_context3.next=13;return regeneratorRuntime.awrap(
this.readConfig('.taskrc','ui.task'));case 13:taskPath=_context3.sent;if(!
taskPath){_context3.next=20;break;}
this.config.task=taskPath;_context3.next=18;return regeneratorRuntime.awrap(
this.checkTask());case 18:if(!_context3.sent){_context3.next=20;break;}return _context3.abrupt('return',
true);case 20:

;return _context3.abrupt('return',
false);case 22:case'end':return _context3.stop();}}},null,this);}},{key:'init',value:function init(){var _this=this;return regeneratorRuntime.async(function init$(_context4){while(1){switch(_context4.prev=_context4.next){case 0:_context4.next=2;return regeneratorRuntime.awrap(



this.findBinary());case 2:if(_context4.sent){_context4.next=4;break;}return _context4.abrupt('return',
false);case 4:

ipcRenderer.on('state',function(evt,state){
_this.config.onState(state);
});
window.addEventListener('online',function(e){

if(navigator.onLine){
_this.config.onState('online');
};
});return _context4.abrupt('return',
true);case 7:case'end':return _context4.stop();}}},null,this);}},{key:'start',value:function start(


controller){var map,conf,key;return regeneratorRuntime.async(function start$(_context5){while(1){switch(_context5.prev=_context5.next){case 0:
map={};
conf=controller.config('ui.shortcut.',true);
if(Object.keys(conf).length==0){

map={
sync:{
key:'CmdOrCtrl+Alt+X',
command:'sync'},

show:{
key:'CmdOrCtrl+Alt+D',
command:'show'},

add:{
key:'CmdOrCtrl+Alt+A',
command:'add'}};


}
ipcRenderer.on('shortcut',function(evt,code){
if(map[code]){
controller.events.emit('shortcut',code,map[code]);
};
});
for(key in map){
ipcRenderer.send('set-shortcut',map[key].key,key);
}
controller.events.on('shortcut',function(code,config){
if(['show','add'].includes(config.command)){
ipcRenderer.send('raise');
};
});case 6:case'end':return _context5.stop();}}},null,this);}},{key:'configurePanes',value:function configurePanes(


conf){
conf._modes={
"dock":true,
"float":true,
"hidden":true};

conf._default='dock';
if(conf.limit===0)
conf.limit=100;
return conf;
}},{key:'configureSync',value:function configureSync(

config){
return{
normal:60,
error:10,
commit:10};

}},{key:'call',value:function call(

args,out,err){var _this2=this;var options=arguments.length>3&&arguments[3]!==undefined?arguments[3]:{};

var yesno=/^(.+)\s\((\S+)\)\s$/;
return new Promise(function(resp,rej){
var handleQuestion=function _callee(question,choices){var answer;return regeneratorRuntime.async(function _callee$(_context6){while(1){switch(_context6.prev=_context6.next){case 0:_context6.next=2;return regeneratorRuntime.awrap(
_this2.config.onQuestion(question,choices));case 2:answer=_context6.sent;if(!(
answer===undefined)){_context6.next=6;break;}
task.kill();return _context6.abrupt('return');case 6:


task.stdin.write(answer[0]+'\n');case 7:case'end':return _context6.stop();}}},null,_this2);};

var stream2out=function stream2out(stream,outp,has_question){
stream.setEncoding('utf8');
var head='';
stream.on('data',function(line){
var eat_all=line&&line[line.length-1]=='\n';
var lines=(head+line).split('\n');
head='';
lines.forEach(function(l,idx){
var last=idx==lines.length-1;
if(!last||eat_all){
outp&&outp.eat(l);
return;
};
if(has_question){
var m=l.match(yesno);

if(m){
options.flush&&options.flush();
handleQuestion(m[1],m[2].split('/'));
return;
}
}
head=l;
});
});
};
var arr=[];var _iteratorNormalCompletion=true;var _didIteratorError=false;var _iteratorError=undefined;try{
for(var _iterator=args[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step;!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=true){var s=_step.value;
if(!s)continue;
if(s[0]=='('&&s[s.length-1]==')'){
arr.push(s);
continue;
}
if(s[0]=='"'&&s[s.length-1]=='"'){
arr.push(s.substr(1,s.length-2));
continue;
}
arr.push.apply(arr,s.split(' '));
}}catch(err){_didIteratorError=true;_iteratorError=err;}finally{try{if(!_iteratorNormalCompletion&&_iterator.return){_iterator.return();}}finally{if(_didIteratorError){throw _iteratorError;}}}
var task=void 0;
task=spawn(_this2.config.task||'task',arr);
stream2out(task.stdout,out,options.question);
stream2out(task.stderr,err,false);
task.on('close',function(code){
if(options.slow){
setTimeout(function(){
resp(code);
},1);
}else{
resp(code);
}
});
task.on('error',function(err){
rej(err);
});
});
}},{key:'schedule',value:function schedule(

seconds,type,interval){var _this3=this;

if(this.timerIDs[type]){
var clrFn=interval?clearInterval:clearTimeout;
clrFn(this.timerIDs[type]);
delete this.timerIDs[type];
};
if(seconds>0){
var setFn=interval?setInterval:setTimeout;
this.timerIDs[type]=setFn(function(){
_this3.config.onTimer(type);
},seconds*1000);
};
}}]);return TaskProvider;}();