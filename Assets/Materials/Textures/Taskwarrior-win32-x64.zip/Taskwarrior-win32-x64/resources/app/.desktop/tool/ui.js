"use strict";Object.defineProperty(exports,"__esModule",{value:true});var smooth=exports.smooth=function smooth(fn){for(var _len=arguments.length,args=Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){args[_key-1]=arguments[_key];}
return new Promise(function(rsp,rej){
setTimeout(function _callee(){var result;return regeneratorRuntime.async(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:_context.prev=0;_context.next=3;return regeneratorRuntime.awrap(

fn.apply(null,args));case 3:result=_context.sent;
rsp(result);_context.next=10;break;case 7:_context.prev=7;_context.t0=_context["catch"](0);

rej(_context.t0);case 10:case"end":return _context.stop();}}},null,undefined,[[0,7]]);},

1);
});
};