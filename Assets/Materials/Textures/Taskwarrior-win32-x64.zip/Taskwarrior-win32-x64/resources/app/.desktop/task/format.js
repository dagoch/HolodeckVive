'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.calcColorStyles=exports.sortTasks=exports.formatters=exports.isoDate=exports.parseDate=undefined;var _slicedToArray=function(){function sliceIterator(arr,i){var _arr=[];var _n=true;var _d=false;var _e=undefined;try{for(var _i=arr[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_s;!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break;}}catch(err){_d=true;_e=err;}finally{try{if(!_n&&_i["return"])_i["return"]();}finally{if(_d)throw _e;}}return _arr;}return function(arr,i){if(Array.isArray(arr)){return arr;}else if((typeof Symbol==='function'?Symbol.iterator:'@@iterator')in Object(arr)){return sliceIterator(arr,i);}else{throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();var _style=require('../styles/style');
var _main=require('../styles/main');


var parseDate=exports.parseDate=function parseDate(s){
if(!s||s.length!=16){
return undefined;
}
var msec=Date.UTC(s.substr(0,4),parseInt(s.substr(4,2))-1,s.substr(6,2),s.substr(9,2),s.substr(11,2),s.substr(13,2));
return new Date(msec);
};

var dateRelative=function dateRelative(dt){var now=arguments.length>1&&arguments[1]!==undefined?arguments[1]:new Date();
var sec=Math.round((dt.getTime()-now.getTime())/1000);
var mul=sec>0?1:-1;
var asec=Math.abs(sec);
if(asec<60){
return[sec,'s'];
};
if(asec<60*60){
return[mul*Math.round(asec/60),'m'];
};
if(asec<60*60*24){
return[mul*Math.ceil(asec/60/60),'h'];
};
var days=Math.ceil(asec/60/60/24);
if(days<10){
return[mul*days,'d'];
};
if(days<30){
return[mul*Math.ceil(days/7),'w'];
};
if(days<360){
return[mul*Math.ceil(days/30),'mo'];
};
return[mul*Math.ceil(days/36)/10,'y'];
};

var isoDate=exports.isoDate=function isoDate(dt){
var pad=function pad(number){
if(number<10){
return'0'+number;
}
return number;
};
return dt.getFullYear()+'-'+pad(dt.getMonth()+1)+'-'+pad(dt.getDate());
};

var formatDate=function formatDate(obj,format,name,editable){
var dt=parseDate(obj[name]);
if(!dt){
if(editable)
obj[name+'_edit']=name+':';
return'';
};
obj[name+'_date']=dt;
obj[name+'_title']=dt.toLocaleString();
if(editable){
var dt_iso=isoDate(dt);
obj[name+'_edit']=name+':'+dt_iso;
}
if(format=='iso'){
return obj[name];
};
if(['age','relative','remaining'].indexOf(format)!=-1){var _dateRelative=
dateRelative(dt),_dateRelative2=_slicedToArray(_dateRelative,2),val=_dateRelative2[0],sfx=_dateRelative2[1];
var mul=format=='age'?-1:1;
return''+mul*val+sfx;
};
return dt.toLocaleDateString();
};

var formatters=exports.formatters={
id:function id(obj){

return''+(obj.id||'');
},
due:function due(obj,format){
return formatDate(obj,format,'due',true);
},
modified:function modified(obj,format){
obj.modified_ro=true;
return formatDate(obj,format,'modified');
},
entry:function entry(obj,format){
obj.entry_ro=true;
return formatDate(obj,format,'entry');
},
start:function start(obj,format){
obj.start_ro=true;
var val=formatDate(obj,format,'start');
if(val&&format=='active'){
return'*';
};
return val;
},
end:function end(obj,format){
obj.end_ro=true;
return formatDate(obj,format,'end');
},
wait:function wait(obj,format){
return formatDate(obj,format,'wait',true);
},
scheduled:function scheduled(obj,format){
return formatDate(obj,format,'scheduled',true);
},
until:function until(obj,format){
return formatDate(obj,format,'until',true);
},
description:function description(obj,format){
var ann=obj.annotations||[];
var desc=obj.description||'';
obj.description_truncate=['truncated','truncated_count'].indexOf(format)!=-1;
if(format=='desc'||format=='truncated'){
return desc;
}
if(format=='count'||format=='truncated_count'){
if(ann.length){
obj.description_count='['+ann.length+']';
}
return desc;
}
var lines=ann.map(function(line){
var dt=parseDate(line.entry);
var outp='';
outp+=line.description;
return{
text:outp,
origin:line.description,
unique:line.entry,
date:dt,
title:dt?dt.toLocaleString():line.description};

});
if(format=='oneline'){
lines.forEach(function(line){
desc+=' '+line.text;
});
return desc;
};
obj.description_ann=lines;
return desc;
},
tags:function tags(obj,format){
var tags=obj.tags||[];
obj.tags_title=tags.join(' ');
obj.tags_edit='+';
if(!tags.length){
return'';
};
if(format=='indicator'){
return'+';
};
if(format=='count'){
return'['+tags.length+']';
};
obj.tags_edit+=tags.join(' +');
return tags.join(' ')+' ';
},
project:function project(obj,format){
var val=obj.project||'';
obj.project_edit='pro:'+val;
if(!val){
return val;
};
var parts=val.split('.');
if(format=='parent'){
return parts.slice(0,parts.length-1).join('.');
};
if(format=='indented'){
return Array(parts.length-1).fill('  ').join('')+parts[parts.length-1];
};
return val;
},
uuid:function uuid(obj,format){

var val=obj.uuid||'';
obj.uuid_title=val;
var minus=val.indexOf('-');
if(!val||minus==-1){

return'';
}
if(format=='short'){
return val.substr(0,minus);
}
return val;
},
urgency:function urgency(obj,format){
obj.urgency_ro=true;
var val=obj.urgency||0;
if(format=='integer'){
return''+Math.ceil(val);
}
return''+Math.round(10*val)/10;
},
recur:function recur(obj,format){
var val=obj.recur||'';
obj.recur_title=val;
obj.recur_edit='recur:'+val;
if(format=='indicator'&&val){
return'R';
}
return val;
},
depends:function depends(obj,format){
obj.depends_ro=true;
var arr=obj.dependsTasks||obj.depends||[];
if(arr.length){
obj.depends_sort=arr.length;
obj.depends_title='['+arr.length+']';
if(obj.dependsTasks){
obj.dependsList=true;
if(obj.dependsTasks.length<=2){
obj.depends_title=obj.dependsTasks.map(function(t){return t.id;}).join(' ');
};
};
if(format=='count'){
return obj.depends_title;
};
if(format=='indicator'){
return'D';
}
if(obj.dependsTasks){
return obj.depends_title;
};
return'['+arr.length+']';
}
obj.depends_sort=0;
return'';
},
uda:function uda(obj,format,item,controller){
var val=obj[item.field]||'';
obj[item.field+'_edit']=item.field+':'+val;
if(!val)return'';
if(format=='indicator'&&val){
return'*';
};
var type=controller.udas[item.field].type;
if(type=='date'){
return formatDate(obj,format,item.field,true);
};
if(type=='numeric'){
return''+Math.round(10*val)/10;
};
return val;
}};



var sortTasks=exports.sortTasks=function sortTasks(info,mode){
var tasks=info.tasks.sort(function(a,b){var _iteratorNormalCompletion=true;var _didIteratorError=false;var _iteratorError=undefined;try{
for(var _iterator=info.sort[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step;!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=true){var item=_step.value;
var mul=item.asc?1:-1;
var _a=a[item.field+'_sort']||a[item.field];
var _b=b[item.field+'_sort']||b[item.field];
if(_a===_b){
continue;
}
if(_a===undefined){
return 1;
}
if(_b===undefined){
return-1;
}
return _a>_b?mul:-1*mul;
}}catch(err){_didIteratorError=true;_iteratorError=err;}finally{try{if(!_iteratorNormalCompletion&&_iterator.return){_iterator.return();}}finally{if(_didIteratorError){throw _iteratorError;}}}
return 0;
});
if(mode=='tree'||mode=='tree_back'){
var result=[];
var addAll=function addAll(task,level){
task.level=level;
result.push(task);
task.sub.forEach(function(t){
addAll(t,level+1);
});
};
tasks.forEach(function(task){
task.sub=[];
});
tasks.forEach(function(task){
if(task.depends){
task.depends.findIndex(function(uuid){
var t=tasks.find(function(t){
return t.uuid==uuid;
});
if(t){
if(mode=='tree'){
t.sub.push(task);
task.child=true;
return true;
}else{
task.sub.push(t);
t.child=true;
};
}
return false;
});
};
});
tasks.forEach(function(task){
if(!task.child){
addAll(task,0);
}
});
return result;
};
return tasks;
};

var coloring={
tagged:function tagged(task){
if(task.tags&&task.tags.length){
return['tagged'];
};
},
recurring:function recurring(task){
if(task.recur)return['recurring'];
},
blocked:function blocked(task){
if(task.depends&&task.depends_title)return['blocked'];
},
due:function due(task,colors,controller){
if(task.due_date&&controller.dueDays>0){
var now=new Date();
now=new Date(now.getFullYear(),now.getMonth(),now.getDate()+controller.dueDays);
if(now.getTime()>task.due_date.getTime()){
return['due'];
};
}
},
'due.today':function dueToday(task){
if(task.due_date){
var now=new Date();
var start=new Date(now.getFullYear(),now.getMonth(),now.getDate());
var finish=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1);
if(task.due_date.getTime()>=start.getTime()&&task.due_date.getTime()<finish.getTime()){
return['due.today'];
};
}
},
scheduled:function scheduled(task){
if(task.scheduled)return['scheduled'];
},
overdue:function overdue(task){
if(task.due_date){
var now=new Date();
var finish=new Date(now.getFullYear(),now.getMonth(),now.getDate());
if(task.due_date.getTime()<finish.getTime()){
return['overdue'];
};
}
},
'project.':function project(task,colors){
var project=task.project||'none';
var name='';
var cls=[];var _iteratorNormalCompletion2=true;var _didIteratorError2=false;var _iteratorError2=undefined;try{
for(var _iterator2=project.split('.')[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step2;!(_iteratorNormalCompletion2=(_step2=_iterator2.next()).done);_iteratorNormalCompletion2=true){var part=_step2.value;
if(name)name+='.';
name+=part;
if(colors['project.'+name]){
cls.push('project.'+name);
}
}}catch(err){_didIteratorError2=true;_iteratorError2=err;}finally{try{if(!_iteratorNormalCompletion2&&_iterator2.return){_iterator2.return();}}finally{if(_didIteratorError2){throw _iteratorError2;}}}
if(task.project&&!cls.length){

return['project.'];
}
return cls;
},
'tag.':function tag(task,colors){
var tags=task.tags||[];
if(!tags.length&&colors['tag.none']){
return['tag.none'];
};
var cls=[];var _iteratorNormalCompletion3=true;var _didIteratorError3=false;var _iteratorError3=undefined;try{
for(var _iterator3=tags[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step3;!(_iteratorNormalCompletion3=(_step3=_iterator3.next()).done);_iteratorNormalCompletion3=true){var tag=_step3.value;
if(colors['tag.'+tag]){
cls.push('tag.'+tag);
}
}}catch(err){_didIteratorError3=true;_iteratorError3=err;}finally{try{if(!_iteratorNormalCompletion3&&_iterator3.return){_iterator3.return();}}finally{if(_didIteratorError3){throw _iteratorError3;}}}
if(tags.length&&!cls.length){

return['tag.'];
}
return cls;
},
'uda.':function uda(task,colors,controller){
var cls=[];
for(var key in controller.udas){
var val=task[key];
if(val&&colors['uda.'+key]){
cls.push('uda.'+key);
}
if(val&&colors[('uda.'+key+'.'+val).toLowerCase()]){
cls.push(('uda.'+key+'.'+val).toLowerCase());
}
if(!val&&colors['uda.'+key+'.none']){
cls.push('uda.'+key+'.none');
}
}
return cls;
},
completed:function completed(task){
if(task.status=='completed')return['completed'];
},
deleted:function deleted(task){
if(task.status=='deleted')return['deleted'];
},
active:function active(task){
if(task.start)return['active'];
}};


var calcColorStyles=exports.calcColorStyles=function calcColorStyles(task,precedence,controller){
var clrDef=(0,_style.colors)();
var result=[];var _iteratorNormalCompletion4=true;var _didIteratorError4=false;var _iteratorError4=undefined;try{
for(var _iterator4=precedence[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step4;!(_iteratorNormalCompletion4=(_step4=_iterator4.next()).done);_iteratorNormalCompletion4=true){var rule=_step4.value;
if(!coloring[rule])continue;
var sts=coloring[rule](task,clrDef,controller);
if(!sts)continue;var _iteratorNormalCompletion5=true;var _didIteratorError5=false;var _iteratorError5=undefined;try{
for(var _iterator5=sts[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_step5;!(_iteratorNormalCompletion5=(_step5=_iterator5.next()).done);_iteratorNormalCompletion5=true){var st=_step5.value;
if(_main.styles['color_'+st+'_bg']){
result.push(_main.styles['color_'+st+'_bg']);
};
}}catch(err){_didIteratorError5=true;_iteratorError5=err;}finally{try{if(!_iteratorNormalCompletion5&&_iterator5.return){_iterator5.return();}}finally{if(_didIteratorError5){throw _iteratorError5;}}}
}}catch(err){_didIteratorError4=true;_iteratorError4=err;}finally{try{if(!_iteratorNormalCompletion4&&_iterator4.return){_iterator4.return();}}finally{if(_didIteratorError4){throw _iteratorError4;}}}
return result;
};