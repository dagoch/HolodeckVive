'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.EventEmitter=undefined;var _events=require('events');var _events2=_interopRequireDefault(_events);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}

var EventEmitter=exports.EventEmitter=_events2.default;