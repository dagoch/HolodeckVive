'use strict';Object.defineProperty(exports,"__esModule",{value:true});exports.makeCommon=undefined;var _slicedToArray=function(){function sliceIterator(arr,i){var _arr=[];var _n=true;var _d=false;var _e=undefined;try{for(var _i=arr[typeof Symbol==='function'?Symbol.iterator:'@@iterator'](),_s;!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break;}}catch(err){_d=true;_e=err;}finally{try{if(!_n&&_i["return"])_i["return"]();}finally{if(_d)throw _e;}}return _arr;}return function(arr,i){if(Array.isArray(arr)){return arr;}else if((typeof Symbol==='function'?Symbol.iterator:'@@iterator')in Object(arr)){return sliceIterator(arr,i);}else{throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();var _style=require('./style');

var makeCommon=exports.makeCommon=function makeCommon(style){var _layers2=
(0,_style.layers)(),_layers3=_slicedToArray(_layers2,2),_layers=_layers3[0],_colorDefs=_layers3[1];
var _fontFamily=(0,_style.fontFamily)();
var _layersStyle=(0,_style.layersStyle)(_layers,_fontFamily);
var _colorsStyle=(0,_style.layersStyle)(_colorDefs,_fontFamily);
var _styles={
"wflex":{
flexWrap:'wrap'},

"hbar":{
alignItems:"center"},

"eflex":{
justifyContent:"flex-end"},

right_pane:{
width:_layers.panes.right.width,
backgroundColor:_layers.bg.bg},

left_pane:{
width:_layers.panes.left.width,
backgroundColor:_layers.bg.bg},

paneTitle:{
marginLeft:5}};


for(var key in _layersStyle){
style[key]=_layersStyle[key];
};
for(var key in _styles){
style[key]=_styles[key];
};
for(var key in _colorsStyle){
style['color_'+key]=_colorsStyle[key];
};
return style;
};