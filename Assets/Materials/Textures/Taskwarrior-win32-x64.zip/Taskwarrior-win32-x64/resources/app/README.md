# README #

TaskwarriorC2 is cross platform GUI client for Taskwarrior. Currently works on Linux, OS X. Windows version is under consideration.

Android version is under development now. 

![tw.png](https://bitbucket.org/repo/zkKpqM/images/2910762113-tw.png)

Want to try current version?

* Install latest node.js, if you don't have it
* Checkout this project
* Execute following:
```
npm install
npm run dist
```
* Run application using following:
```
node_modules/.bin/electron desktop.js
```