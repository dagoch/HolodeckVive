import EM from 'events';

export const EventEmitter = EM;

